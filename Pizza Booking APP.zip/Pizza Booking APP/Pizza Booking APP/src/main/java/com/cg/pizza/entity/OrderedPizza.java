package com.cg.pizza.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
@Entity
@Table(name="orderedpizza")
@SequenceGenerator(name = "seq_ordereditems", sequenceName = "myseqorderitems", allocationSize = 1,initialValue = 500)
public class OrderedPizza {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_ordereditems")
	private int billId;
	 @Size(max = 100, message = "Pizza name must not exceed 100 characters")
	  @NotNull(message = "Pizza name must not be null")
	private String pizzaName;
	@Min(value=1)
	private int quantity;
	@ManyToOne
	@JoinColumn(name="orderId")
	@NotNull
	private Orders order;
	public OrderedPizza() {
	}
	public OrderedPizza(int billId, String pizzaName, int quantity, Orders order) {
		super();
		this.billId = billId;
		this.pizzaName = pizzaName;
		this.quantity = quantity;
		this.order = order;
	}
	public String getPizzaName() {
		return pizzaName;
	}
	public void setPizzaName(String pizzaName) {
		this.pizzaName = pizzaName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getBillId() {
		return billId;
	}
	public void setBillId(int billId) {
		this.billId = billId;
	}
	public Orders getOrder() {
		return order;
	}
	public void setOrder(Orders order) {
		this.order = order;
	}
    
}
