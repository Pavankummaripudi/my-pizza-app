package com.cg.pizza.serviceimpl;
 
import java.util.List;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.pizza.entity.Category;
import com.cg.pizza.exceptions.ApplicationException;
import com.cg.pizza.repository.CategoryRepository;
import com.cg.pizza.service.CategoryService;
 
@Component
public class CategoryServiceImpl implements CategoryService{
	@Autowired
	private CategoryRepository categoryRepository;
	@Override
	public Category addCategory(Category category) {
		
		category.setCategoryName(category.getCategoryName().toLowerCase());
		return categoryRepository.save(category);
	}
	@Override
	public List<Category> allCategory() {
		
		return categoryRepository.findAll();
	}
	@Override
 
	public Category updateCategory(Category c,int categoryId) {
		
		Optional<Category> category= categoryRepository.findById(categoryId);
		if(category.isPresent()) {
			Category existingCategory=category.get();
			existingCategory.setCategoryName(c.getCategoryName().toLowerCase());
			return categoryRepository.save(existingCategory);
		}
		throw new ApplicationException("Invalid Category");
	}
	@Override
 
	public Category searchCategoryById(int categoryId) {
		return categoryRepository.findById(categoryId).orElseThrow(()-> new ApplicationException("Category Not Found"));
		
	}
	@Override
 
	public void deleteCategory(int categoryId) {
		
		categoryRepository.deleteById(categoryId);
	}
	@Override
	public Category searchCategoryByName(String name) {
		return categoryRepository.findByCategoryName(name).orElseThrow(()-> new ApplicationException("Category Not Found"));
	}
}