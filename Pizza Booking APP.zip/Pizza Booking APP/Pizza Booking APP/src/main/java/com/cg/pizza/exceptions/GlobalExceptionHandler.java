package com.cg.pizza.exceptions;

import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException;

@RestControllerAdvice
public class GlobalExceptionHandler {

@ExceptionHandler(ApplicationException.class)
public ResponseEntity<ApiError>handle(ApplicationException e )
{
	ApiError error = new ApiError();
	error.setMsg(e.getMessage());
	return  new ResponseEntity<ApiError>(error, HttpStatusCode.valueOf(404));	
}
@ExceptionHandler(HttpClientErrorException.Unauthorized.class)
@ResponseBody
public String handleUnauthorizedException(HttpClientErrorException.Unauthorized ex) {
    // Customize the response message or redirect the user to a login page
    return "Unauthorized access: " + ex.getMessage();
}
}
