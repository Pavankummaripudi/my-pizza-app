package com.cg.pizza.service;
 
import java.util.List;

import com.cg.pizza.entity.Category;
 
public interface CategoryService {
		public Category addCategory(Category category);
		public List<Category> allCategory();
		public Category searchCategoryById(int categoryId);
		public Category searchCategoryByName(String name);
		public Category updateCategory(Category c,int categoryId);
		public void deleteCategory(int categoryId);
 
}