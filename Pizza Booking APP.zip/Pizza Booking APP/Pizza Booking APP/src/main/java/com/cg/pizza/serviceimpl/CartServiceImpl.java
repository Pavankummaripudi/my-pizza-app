package com.cg.pizza.serviceimpl;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.pizza.dto.CartDTO;
import com.cg.pizza.dto.PizzaToppingsDTO;
import com.cg.pizza.entity.Cart;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.Pizza;
import com.cg.pizza.entity.PizzaToppings;
import com.cg.pizza.entity.Toppings;
import com.cg.pizza.exceptions.ApplicationException;
import com.cg.pizza.repository.CartRepository;
import com.cg.pizza.repository.CustomerRepo;
import com.cg.pizza.repository.PizzaRepository;
import com.cg.pizza.repository.PizzaToppingsRepository;
import com.cg.pizza.repository.ToppingsRepository;
import com.cg.pizza.service.CartService;

import jakarta.transaction.Transactional;
 
@Service
@Transactional
public class CartServiceImpl implements CartService {
	@Autowired
	private PizzaRepository pizzaRepository;
	@Autowired
	private CartRepository cartRepository;
	@Autowired
	private CustomerRepo customerRepository;
	@Autowired
	private ToppingsRepository toppingsRepository;
	@Autowired
	private PizzaToppingsRepository ptRepo;
 
	@Override
	public Cart addPizzatoCart(CartDTO cartDTO) {	
		Customer customer = customerRepository.findById(cartDTO.getCustomerId())
				.orElseThrow(() -> new ApplicationException("Customer not found"));	
		System.out.println(customer);
		
		PizzaToppings pt = ptRepo.findById(cartDTO.getPizzaToppingId()).orElseThrow(() -> new ApplicationException("PizzaTopping not found"));	
		 Cart existingItem = cartRepository.findByCustomer(customer);
		 System.out.println(existingItem);
		 if (existingItem == null) {
		 Cart cart = new Cart();
		cart.setCustomer(customer);
		List<PizzaToppings> pizzaTopping = new ArrayList<>();
		pizzaTopping.add(pt);
		cart.setPizzaToppings(pizzaTopping);
		cartRepository.save(cart);
		
		return cart;
	} else {
		
		List<PizzaToppings> pizzaTopping = existingItem.getPizzaToppings();
		pizzaTopping.add(pt);
		existingItem.setPizzaToppings(pizzaTopping);
	    cartRepository.save(existingItem);
	    return existingItem;
	}
	}
	@Override
	public Cart getCartItemsByCustomerId(int customerId) {
		Customer customer = customerRepository.findById(customerId).orElseThrow(()->new ApplicationException("Customer Not Found"));
		return cartRepository.findByCustomer(customer);
	}
 
	@Override
	public PizzaToppings updatePizzaQuantity(PizzaToppingsDTO ptDTO) {
		Pizza pizza=pizzaRepository.findByPizzaId(ptDTO.getPizzaId());
		PizzaToppings pt = ptRepo.findByPizza(pizza);
		pt.setPizzaQuantity(ptDTO.getPizzaQuantity());		
		return ptRepo.save(pt);
	}
	
 
	@Override
	public void deleteCartItemsByCustomerId(int customerId) {
	    Customer customer = customerRepository.findById(customerId).orElseThrow(()->new ApplicationException("Customer Not Found"));
		Cart cartItems = cartRepository.findByCustomer(customer);
		cartRepository.delete(cartItems);
	}
 
	public void deletePizzafromCart(int pizzaId) {
		
		cartRepository.deleteById(pizzaId);;
	}

	@Override
	public double getTotalOrderPrice(Customer c) {
	    double total = 0.0;
	    Cart cart = cartRepository.findByCustomer(c);
	   
	    List<PizzaToppings> pizzaToppings =  cart.getPizzaToppings();
	    for(PizzaToppings p:pizzaToppings) {
	        Pizza pizza = p.getPizza();
	        List<Toppings> topping =  p.getToppings();

	        double pizzaTotal = pizza.getPizzaPrice() * p.getPizzaQuantity();
	        double toppingTotal =0;
	        for(Toppings t:topping)
	        	toppingTotal+=t.getToppingPrice();

	        total += pizzaTotal + toppingTotal;
	    }
	    return total;
	}

	@Override
	public PizzaToppings addPizzaToppings(PizzaToppingsDTO ptDTO, int toppingId) {
		// TODO Auto-generated method stub
		PizzaToppings pt=new PizzaToppings();
		Pizza p = pizzaRepository.findByPizzaId(ptDTO.getPizzaId());
		if(toppingId==0) {
			pt.setPizza(p);
			List<Toppings> top = null;
			pt.setToppings(top);
			pt.setPizzaQuantity(1);
		}
		else {
			pt.setPizza(p);
			List<Toppings> top = new ArrayList<Toppings>();
			Toppings t = toppingsRepository.findById(toppingId).get();
			top.add(t);
			pt.setToppings(top);
			pt.setPizzaQuantity(1);
		}
		return ptRepo.save(pt);
	}

	@Override
	public void deletePizzaToppings(int pizzaToppingId) {
		// TODO Auto-generated method stub
		ptRepo.deleteById(pizzaToppingId);
	}
	@Override
	public List<PizzaToppings> getAllPizzaToppings(){
		return ptRepo.findAll();
		
	}

}