package com.cg.pizza.service;
 
import java.util.List;

import com.cg.pizza.dto.FeedbackDTO;
import com.cg.pizza.entity.FeedBack;
 
 
public interface FeedbackService {
 
	public FeedBack addFeedback(FeedbackDTO fdb);
	public FeedBack getFeedback(int feedbackId);
	public List<FeedBack> getAllFeedback();
	public FeedBack updateFeedback(FeedbackDTO fdto);
	public void deleteFeedback(int feedbackId);
	public List<FeedBack> searchByCustomerIdService(int customerId);
	public List<FeedBack> searchByPizzaIdService(int pizzaId);
}