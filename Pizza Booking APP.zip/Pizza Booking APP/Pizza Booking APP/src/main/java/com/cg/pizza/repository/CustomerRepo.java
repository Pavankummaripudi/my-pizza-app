package com.cg.pizza.repository;
import org.springframework.stereotype.Repository;

import com.cg.pizza.entity.Customer;

import org.springframework.data.jpa.repository.JpaRepository;
@Repository
public interface CustomerRepo extends JpaRepository<Customer, Integer> {
 
      Customer findByMobileNumber(String mobileNumber);
      Customer findByEmail(String email);
      Customer findByUsername(String username);
}