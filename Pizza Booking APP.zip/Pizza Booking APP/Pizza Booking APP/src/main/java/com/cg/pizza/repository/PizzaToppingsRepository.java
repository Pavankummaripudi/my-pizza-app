package com.cg.pizza.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.pizza.entity.Pizza;
import com.cg.pizza.entity.PizzaToppings;

@Repository
public interface PizzaToppingsRepository extends JpaRepository<PizzaToppings, Integer>{
	PizzaToppings findByPizza(Pizza pizza);
	
}
