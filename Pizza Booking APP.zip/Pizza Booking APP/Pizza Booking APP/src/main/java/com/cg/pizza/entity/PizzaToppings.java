package com.cg.pizza.entity;

import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
@Entity
public class PizzaToppings {
	@Id
	@GeneratedValue
	private int ptId;
	@Min(value = 1, message = "Pizza quantity must be at least 1")
	private int pizzaQuantity;
	@ManyToOne
	@JoinColumn(name="pizzaId")
	@NotNull(message = "Pizza must not be null")
	private Pizza pizza;
	@ManyToMany
	private List<Toppings> toppings;
	
	public Pizza getPizza() {
		return pizza;
	}
	public void setPizza(Pizza pizza) {
		this.pizza = pizza;
	
	}
	
	public int getPtId() {
		return ptId;
	}
	public void setPtId(int ptId) {
		this.ptId = ptId;
	}
	public int getPizzaQuantity() {
		return pizzaQuantity;
	}
	public void setPizzaQuantity(int pizzaQuantity) {
		this.pizzaQuantity = pizzaQuantity;
	}
	public List<Toppings> getToppings() {
		return toppings;
	}
	public void setToppings(List<Toppings> toppings) {
		this.toppings = toppings;
	}
	
	public PizzaToppings(Pizza pizza, List<Toppings> toppings,int pizzaQuantity) {
		super();
		this.pizza = pizza;
		this.toppings = toppings;
		this.pizzaQuantity=pizzaQuantity;
	}
	public PizzaToppings() {
		// TODO Auto-generated constructor stub
	}

}
