package com.cg.pizza.exceptions;

public class ApplicationException extends RuntimeException {

	public ApplicationException(String msg)
	{

		super(msg);

	}
 
}
