package com.cg.pizza.serviceimpl;

import java.time.LocalDate;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.pizza.entity.Cart;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.OrderedPizza;
import com.cg.pizza.entity.Orders;
import com.cg.pizza.entity.Pizza;
import com.cg.pizza.entity.PizzaToppings;
import com.cg.pizza.exceptions.ApplicationException;
import com.cg.pizza.repository.CartRepository;
import com.cg.pizza.repository.CustomerRepo;
import com.cg.pizza.repository.OrderedPizzaRepository;
import com.cg.pizza.repository.OrdersRepository;
import com.cg.pizza.service.CartService;
import com.cg.pizza.service.OrdersService;
@Service
@Transactional
public class OrderServiceImpl implements OrdersService{

	@Autowired
	private OrdersRepository ordersRepository;
	@Autowired
	private OrderedPizzaRepository orderedPizzaRepository;
	@Autowired
	private CustomerRepo customerRepository;
	@Autowired
	private CartRepository cartRepository;
	@Autowired
	private CartService cartService;
	
	@Override
	public Orders addOrder(int customerId) {
		    Customer customer = customerRepository.findById(customerId).orElseThrow(()-> new ApplicationException("Invalid Customer"));
			Cart carts = cartRepository.findByCustomer(customer);
			Orders order = new Orders();
			order.setCustomer(customer);
			order.setOrderDate(LocalDate.now());
			order.setStatus("Confirmed");
//			double totalBill=0;
////			for(Cart cart : carts)
////			{
////				totalBill+=cart.getTotalPrice();
////			}
			order.setBill(cartService.getTotalOrderPrice(customer));
			ordersRepository.save(order);
		     
		    	
		    	List<PizzaToppings> pt = carts.getPizzaToppings();
		    	System.out.println(pt);
		    	for(PizzaToppings p:pt) {
		    		OrderedPizza food = new OrderedPizza();
		    		Pizza pizza = p.getPizza();
		    	food.setPizzaName(pizza.getPizzaName());
		    	food.setQuantity(p.getPizzaQuantity());
		    	food.setOrder(order);
		    	orderedPizzaRepository.save(food);
		    	}
		    	//clears cart after ordering
		    cartRepository.delete(carts);
		    return order;
		}
	@Override
	public List<Orders> findAll() {
		
		return ordersRepository.findAll();
	}

	@Override
	public List<Orders> getOrdersByCustomerId(int customerId) {
		
		Customer customer = customerRepository.findById(customerId).orElseThrow(()-> new ApplicationException("Invalid Customer"));
			return ordersRepository.findByCustomer(customer);
	}

	@Override
	public List<Orders> getOrdersByCustomerNumber(String mobileNumber) {
		
		Customer customer = customerRepository.findByMobileNumber(mobileNumber);
		if(customer==null)
		{
			throw new ApplicationException("Customer not found");
		}
			List<Orders>orderList = ordersRepository.findByCustomer(customer);
			if(orderList.isEmpty())
			{
				throw new ApplicationException("No Orders Found");
			}
			else
			{
				return orderList;
			}
	}


	@Override
	public Orders cancelOrder(int orderId) {
		
		Orders order = ordersRepository.findById(orderId).orElseThrow(()->new ApplicationException("Invalid OrderId"));
		order.setStatus("Cancelled");
		ordersRepository.save(order);
		return order;
	}
	@Override
	public Orders updateOrderStatus(int orderId) {
		Orders order = ordersRepository.findById(orderId).orElseThrow(()->new ApplicationException("Invalid OrderId"));
		order.setStatus("Delivered");
		return ordersRepository.save(order);
	}
}
