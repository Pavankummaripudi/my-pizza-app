package com.cg.pizza.serviceimpl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.pizza.dto.PizzaDTO;
import com.cg.pizza.entity.Category;
import com.cg.pizza.entity.Pizza;
import com.cg.pizza.exceptions.ApplicationException;
import com.cg.pizza.repository.CategoryRepository;
import com.cg.pizza.repository.PizzaRepository;
import com.cg.pizza.service.PizzaService;

import jakarta.transaction.Transactional;
 
@Service
@Transactional
public class PizzaServiceImpl implements PizzaService {
@Autowired
	private PizzaRepository pizzaRepository;


	@Autowired
	private CategoryRepository categoryRepository;

	@Override
	
	public Pizza addPizza(PizzaDTO pizzaDTO) {
		
		Category c= categoryRepository.findById(pizzaDTO.getCategoryId()).orElseThrow(()->new ApplicationException("Invalid Category"));
		Pizza pizza = new Pizza();
		BeanUtils.copyProperties(pizzaDTO, pizza);
		c.setCategoryName(c.getCategoryName().toLowerCase());
		pizza.setCategory(c);
		pizza.setPizzaName(pizzaDTO.getPizzaName().toLowerCase());
		pizza.setPizzaSize(pizzaDTO.getPizzaSize().toLowerCase());
		pizzaRepository.save(pizza);
		return pizza;
	}
	@Override
		public Pizza getByPizzaId(int pizzaId) {
		
		Pizza pizza = pizzaRepository.findById(pizzaId).orElseThrow(() -> new ApplicationException("food not found"));
		return pizza;
	}
	@Override
	public Pizza updatePizza(int pizzaId,PizzaDTO pizzaDTO) {
	    System.out.println("Updating Pizza with ID: " + pizzaId);

	    Pizza pizza = pizzaRepository.findById(pizzaId)
	            .orElseThrow(() -> new ApplicationException("Invalid food item: No food item found with ID " + pizzaId));

	    System.out.println("Retrieved Pizza: " + pizza);

	    // Copy properties excluding the ID to avoid altering it
	    BeanUtils.copyProperties(pizzaDTO, pizza, "pizzaId");

	    // Set the fields explicitly to ensure they are set as intended
	    pizza.setPizzaSize(pizzaDTO.getPizzaSize().toLowerCase());
	    pizza.setPizzaName(pizzaDTO.getPizzaName().toLowerCase());
	    pizza.setPizzaPrice(pizzaDTO.getPizzaPrice());

	    System.out.println("Updated Pizza: " + pizza);

	    // Save the updated entity
	    Pizza updatedPizza = pizzaRepository.save(pizza);

	    System.out.println("Saved Pizza: " + updatedPizza);

	    return updatedPizza;
	}

	@Override
	public void deletePizza(int pizzaId) {
		pizzaRepository.deleteById(pizzaId);
	}
	@Override
	public List<Pizza> findAll() {
		return pizzaRepository.findAll();
	}
	@Override
	public List<Pizza> getPizzaByCategoryId(int categoryId) {
		Optional<Category>category = categoryRepository.findById(categoryId);
		if(category.isPresent())
		{
			return pizzaRepository.findByCategory(category.get());
		}
		else{
			throw new ApplicationException("Category not Found");
		}
	}
	@Override
	public List<Pizza> getPizzaByCategoryName(String categoryName) {
		
		Optional<Category>category = categoryRepository.findByCategoryName(categoryName.toLowerCase());
		if(category.isPresent())
		{
			return pizzaRepository.findByCategory(category.get());
		}
		else{
			throw new ApplicationException("Category not Found");
		}
	}
	@Override
	public List<Pizza> getPizzaBySize(String pizzaSize) {
		
		return pizzaRepository.findAllByPizzaSize(pizzaSize.toLowerCase());
	}
	@Override
	public Pizza getPizzaByName(String pizzaName) {
		
		Pizza pizza = pizzaRepository.findByPizzaName(pizzaName);
		if(pizza==null)
		{
			throw new ApplicationException("Item Not Found");
		}
		return pizza;
	}
}