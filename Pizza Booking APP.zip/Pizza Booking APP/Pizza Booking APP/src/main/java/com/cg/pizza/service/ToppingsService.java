package com.cg.pizza.service;

import java.util.List;

import com.cg.pizza.dto.ToppingsDTO;
import com.cg.pizza.entity.Toppings;

public interface ToppingsService {

	public ToppingsDTO addToppings(ToppingsDTO toppings);

	public String updateToppings(int toppingsId, ToppingsDTO toppingsDTO);

	public String removeToppings(int toppingsId);

	public ToppingsDTO searchToppingsById(int toppingsId);
	public List<Toppings> getAllToppings();
	

}
