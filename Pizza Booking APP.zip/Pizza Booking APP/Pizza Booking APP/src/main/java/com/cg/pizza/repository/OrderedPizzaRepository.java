package com.cg.pizza.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.pizza.entity.OrderedPizza;
import com.cg.pizza.entity.Orders;


public interface OrderedPizzaRepository extends JpaRepository<OrderedPizza, Integer> {
public List<OrderedPizza> findByOrder(Orders order); 
}
