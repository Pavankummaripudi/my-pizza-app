package com.cg.pizza.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.cg.pizza.dto.CustomerDTO;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.repository.CustomerRepo;
import com.cg.pizza.service.CustomerService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/customer")
@SecurityRequirement(name="Bearer Authentication")
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	@Autowired
	private CustomerRepo customerRepository;

	@GetMapping
	public List<Customer> getAllCustomers() {
		return customerService.getAll();
	}

	@GetMapping("/email/{email}")
	public Customer getCustomerByEmail(@PathVariable(value="email")String email) {
		return customerService.getByEmail(email);
	}

	@GetMapping("/number/{mobileNumber}")
	public Customer getCustomerByPhoneNo(@PathVariable(value="mobileNumber")String mobileNumber) {
		return customerService.getByPhoneNo(mobileNumber);
	}

	@PostMapping
	public Customer addCustomerDetails(Principal p,@Valid @RequestBody CustomerDTO customerDto) {
		customerDto.setUsername(p.getName());
		return customerService.addCustomerDetails(customerDto);
	}

	@PutMapping
	public Customer updateCustomerDetails(Principal p,@Valid @RequestBody CustomerDTO customerDto) {
		customerDto.setUsername(p.getName());
		Customer customer = customerRepository.findByUsername(p.getName());
		customerDto.setCustomerId(customer.getCustomerId());
		return customerService.updateCustomerDetails(customerDto);
	}

	@GetMapping("/{customerId}")
	public Customer getCustomerById(@PathVariable("customerId") int customerId) {
		return customerService.getByCustomerId(customerId);
	}
	
	@GetMapping("/username")
	Customer getCustomerByUsername(Principal p) {
		Customer customer = customerRepository.findByUsername(p.getName());
		System.out.println(p.getName());
		return customer;
	}
}