package com.cg.pizza.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.Orders;

@Repository
public interface OrdersRepository extends JpaRepository<Orders, Integer>
{
	public List<Orders>findByCustomer(Customer c);
}