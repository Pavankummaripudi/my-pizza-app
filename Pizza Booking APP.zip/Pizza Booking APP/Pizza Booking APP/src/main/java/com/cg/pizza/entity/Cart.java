package com.cg.pizza.entity;
import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.validation.constraints.NotNull;
 
@Entity
@SequenceGenerator(name = "seq_cart", sequenceName = "myseqcart", allocationSize = 1,initialValue = 400)
public class Cart {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_cart")
	private int cartId;
	private int toppingQuantity=1;
	@OneToOne
	@JoinColumn(name = "customerId")
	@NotNull(message = "Customer must not be null")
	private Customer customer;
	@ManyToMany
	private List<PizzaToppings> pizzaToppings;
	
	public List<PizzaToppings> getPizzaToppings() {
		return pizzaToppings;
	}
	public void setPizzaToppings(List<PizzaToppings> pizzaToppings) {
		this.pizzaToppings = pizzaToppings;
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
 
	public Customer getCustomer() {
		return customer;
	}
 
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
 
	
	public int getToppingQuantity() {
		return toppingQuantity;
	}
	public void setToppingQuantity(int toppingQuantity) {
		this.toppingQuantity = toppingQuantity;
	}
	
	
	public Cart(int cartId, Customer customer, List<PizzaToppings> pizzaToppings,int toppingQuantity) {
		super();
		this.cartId = cartId;
		this.customer = customer;
		this.pizzaToppings = pizzaToppings;
		this.toppingQuantity=toppingQuantity;
	}
	public Cart() {
	}
}