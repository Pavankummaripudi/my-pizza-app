package com.cg.pizza.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name="pizza")
public class Pizza {
	@Id
	@GeneratedValue
	private int pizzaId;	
	@NotBlank(message = "Pizza name is mandatory")
    @Size(min = 3, max = 50, message = "Pizza name must be between 3 and 50 characters")
	private String pizzaName;
   @Min(value = 0, message = "Pizza price must be a positive number")
	private double pizzaPrice;
   @NotBlank(message = "Pizza size is mandatory")
   @Size(min = 1, max = 10, message = "Pizza size must be between 1 and 10 characters")
	private String pizzaSize;
   @NotNull(message = "Category is mandatory")
	@ManyToOne
	@JoinColumn(name="categoryId")
	private Category category;
	public int getPizzaId() {
		return pizzaId;
	}
	public void setPizzaId(int pizzaId) {
		this.pizzaId = pizzaId;
	}
	public String getPizzaName() {
		return pizzaName;
	}
	public void setPizzaName(String pizzaName) {
		this.pizzaName = pizzaName;
	}
	public double getPizzaPrice() {
		return pizzaPrice;
	}
	public void setPizzaPrice(double pizzaPrice) {
		this.pizzaPrice = pizzaPrice;
	}
	public String getPizzaSize() {
		return pizzaSize;
	}
	public void setPizzaSize(String pizzaSize) {
		this.pizzaSize = pizzaSize;
	}
	
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	
	public Pizza(int pizzaId, String pizzaName, double pizzaPrice, String pizzaSize, Category category) {
		super();
		this.pizzaId = pizzaId;
		this.pizzaName = pizzaName;
		this.pizzaPrice = pizzaPrice;
		this.pizzaSize = pizzaSize;
		this.category = category;
	}
	public Pizza() {
		// TODO Auto-generated constructor stub
	}
	

}