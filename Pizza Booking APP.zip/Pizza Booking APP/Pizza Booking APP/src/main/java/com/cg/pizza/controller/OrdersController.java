package com.cg.pizza.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.Orders;
import com.cg.pizza.repository.CustomerRepo;
import com.cg.pizza.service.OrdersService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
@RestController
@RequestMapping("/orders")
@SecurityRequirement(name="Bearer Authentication")
public class OrdersController {
	@Autowired
	private OrdersService os;
	
	@Autowired
	private CustomerRepo customerRepository;
	@GetMapping()
	public List<Orders> getAllOrders()
	{
		return os.findAll();
	}
	@PostMapping()
	public Orders addOrder(Principal p )
	{
		Customer customer = customerRepository.findByUsername(p.getName());
		return os.addOrder(customer.getCustomerId());
	}
	@GetMapping("/cust")
	public List<Orders>getAllOrdersByCustomerId(Principal p)
	{
		Customer customer = customerRepository.findByUsername(p.getName());
		System.out.println(customer.getCustomerId());
		return os.getOrdersByCustomerId(customer.getCustomerId());
	}
	@GetMapping("/mobileno/{mobileno}")
	public List<Orders>getAllOrdersByCustomerNumber(@PathVariable("mobileno") String mobileNumber)
	{
		return os.getOrdersByCustomerNumber(mobileNumber);
	}
	@DeleteMapping("/cancel/{orderId}")
	public Orders cancelOrder(@PathVariable("orderId") int orderId)
	{
		return os.cancelOrder(orderId);
	}
	@PutMapping("/status/{orderId}")
	public Orders updateOrderStatus(@PathVariable("orderId") int orderId)
	{
		return os.updateOrderStatus(orderId);
	}
	
}
