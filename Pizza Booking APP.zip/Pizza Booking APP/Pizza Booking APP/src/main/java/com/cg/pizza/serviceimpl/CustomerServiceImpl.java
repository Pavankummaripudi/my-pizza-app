package com.cg.pizza.serviceimpl;

import java.util.List;

import org.springframework.beans.BeanUtils;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cg.pizza.dto.CustomerDTO;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.exceptions.ApplicationException;
import com.cg.pizza.repository.CustomerRepo;
import com.cg.pizza.service.CustomerService;

import jakarta.transaction.Transactional;

@Service

@Transactional

public class CustomerServiceImpl implements CustomerService {

	@Autowired

	private CustomerRepo customerRepository;

	@Override

	public Customer updateCustomerDetails(CustomerDTO customerdto) {

		Customer c = getByCustomerId(customerdto.getCustomerId());

		BeanUtils.copyProperties(customerdto, c);

		customerRepository.save(c);

		return c;

	}

	@Override

	public Customer getByEmail(String email) {

		Customer customer = customerRepository.findByEmail(email);

		if (customer == null)

		{

			throw new ApplicationException("No Customer Found");

		}

		else

		{

			return customer;

		}

	}

	@Override

	public Customer getByPhoneNo(String mobileNumber) {

		Customer customer = customerRepository.findByMobileNumber(mobileNumber);

		if (customer == null)

		{

			throw new ApplicationException("No Customer Found");

		}

		else

		{

			return customer;

		}

	}

	@Override

	public Customer addCustomerDetails(CustomerDTO customerdto) {

		Customer c = new Customer();

		BeanUtils.copyProperties(customerdto, c);

		customerRepository.save(c);

		return c;

	}

	@Override

	public List<Customer> getAll() {

		return customerRepository.findAll();

	}

	@Override

	public Customer getByCustomerId(int customerId) {

		Customer c = customerRepository.findById(customerId).orElseThrow(() -> new ApplicationException("Invalid Customer Id"));

		return c;

	}
	@Override

	public Customer findByUsername(String username) {

		return customerRepository.findByUsername(username);

	}

}