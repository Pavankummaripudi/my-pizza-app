package com.cg.pizza.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
public class Toppings {
	@Id
	@GeneratedValue
	private int toppingId;
	@NotBlank(message = "Topping name is mandatory")
    @Size(min = 3, max = 50, message = "Topping name must be between 3 and 50 characters")
	private String toppingName;
	@Min(value = 0, message = "Topping price must be a positive number")
	private double toppingPrice;
	
	
	public Toppings() {
		// TODO Auto-generated constructor stub
	}
	
	public Toppings(int toppingId, String toppingName, double toppingPrice, int toppingQuantity) {
		super();
		this.toppingId = toppingId;
		this.toppingName = toppingName;
		this.toppingPrice = toppingPrice;
		
	}

	public int getToppingId() {
		return toppingId;
	}
	public void setToppingId(int toppingId) {
		this.toppingId = toppingId;
	}
	public String getToppingName() {
		return toppingName;
	}
	public void setToppingName(String toppingName) {
		this.toppingName = toppingName;
	}
	public double getToppingPrice() {
		return toppingPrice;
	}
	public void setToppingPrice(double toppingPrice) {
		this.toppingPrice = toppingPrice;
	}
	
	
}
