package com.cg.pizza.service;
 
import java.util.List;

import com.cg.pizza.dto.PizzaDTO;
import com.cg.pizza.entity.Pizza;
 
public interface PizzaService {
 
	public Pizza addPizza(PizzaDTO pizzaDTO);
	public Pizza updatePizza(int pizzaId,PizzaDTO pizzaDTO);
	public Pizza getByPizzaId(int pizzaId);
	public List<Pizza> findAll();
	public List<Pizza> getPizzaByCategoryId(int categoryId);
	public List<Pizza> getPizzaByCategoryName(String categoryName);
	public void deletePizza(int pizzaId);
	public List<Pizza> getPizzaBySize(String size);
	public Pizza getPizzaByName(String pizzaName);
	//public List<Toppings> getToppingsbyPizza(int pizzaId);
}