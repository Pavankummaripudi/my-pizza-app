package com.cg.pizza.controller;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.pizza.dto.PizzaDTO;
import com.cg.pizza.entity.Pizza;
import com.cg.pizza.service.PizzaService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
 
@RestController
@RequestMapping("/pizza")
@SecurityRequirement(name="Bearer Authentication")
public class PizzaController {
	@Autowired
	private PizzaService pizzaService;
	
	@PostMapping
	public Pizza addPizza(@Valid @RequestBody PizzaDTO pizzaDto) {
	System.out.println(pizzaDto);
		return pizzaService.addPizza(pizzaDto);
	}
	@GetMapping("/id/{pizzaId}")
    public Pizza getByPizzaId(@PathVariable("pizzaId") int pizzaId) {
        return pizzaService.getByPizzaId(pizzaId);
	}
	@GetMapping("/size/{size}")
	public List<Pizza> getByPizzaSize(@PathVariable("size")String size)
	{
		return pizzaService.getPizzaBySize(size);
		
	}
	@GetMapping
	public List<Pizza> findAll(){
		return 	pizzaService.findAll();
	}
	@PutMapping("/update/{pizzaId}")
	public Pizza updatePizza( @Valid @PathVariable int pizzaId,@RequestBody PizzaDTO pizzaDto) {
		pizzaDto.setPizzaId(pizzaId);
		return pizzaService.updatePizza(pizzaId,pizzaDto);
	}
	@DeleteMapping("/{pizzaId}")
	public void deletePizza(@PathVariable("pizzaId") int pizzaId ){
		pizzaService.deletePizza(pizzaId);
	}
 
	@GetMapping("/categoryid/{categoryId}")
	public List<Pizza> getPizzaByCategoryId(@PathVariable("categoryId") int categoryId){
		return pizzaService.getPizzaByCategoryId(categoryId);
	}
	@GetMapping("/categoryname/{categoryName}")
	public List<Pizza> getPizzaByCategoryName(@PathVariable("categoryName") String categoryName){
		return pizzaService.getPizzaByCategoryName(categoryName);
	}
	@GetMapping("/pizzaname/{pizzaName}")
	public Pizza getPizzaByName(@PathVariable("pizzaName")String pizzaName)
	{
		return pizzaService.getPizzaByName(pizzaName);
	}
}