package com.cg.pizza.serviceimpl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.pizza.entity.OrderedPizza;
import com.cg.pizza.entity.Orders;
import com.cg.pizza.exceptions.ApplicationException;
import com.cg.pizza.repository.OrderedPizzaRepository;
import com.cg.pizza.repository.OrdersRepository;
import com.cg.pizza.service.OrderedPizzaService;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class OrderedPizzaServiceImpl implements OrderedPizzaService{

	@Autowired
	private OrderedPizzaRepository orderedPizzaRepository;
	@Autowired
	private OrdersRepository ordersRepository;
	
	@Override
	public List<OrderedPizza> getPizzaByOrderId(int orderId) {
		Orders order = ordersRepository.findById(orderId).orElseThrow(()-> new ApplicationException("Invalid OrderId"));
			return orderedPizzaRepository.findByOrder(order);
	}
}
