package com.cg.pizza.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.pizza.entity.OrderedPizza;
import com.cg.pizza.service.OrderedPizzaService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;

@RestController
@RequestMapping("/ordereditems")
@SecurityRequirement(name="Bearer Authentication")
public class OrderedPizzaController {

	@Autowired 
	private OrderedPizzaService orderedPizzaService;
	
	@GetMapping("/{orderId}")
	public List<OrderedPizza> getPizzaByOrderId(@PathVariable("orderId") int orderId)
	{
		return orderedPizzaService.getPizzaByOrderId(orderId);
	}
	
}
