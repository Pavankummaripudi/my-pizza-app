package com.cg.pizza.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.pizza.entity.Cart;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.PizzaToppings;

@Repository
public interface CartRepository  extends JpaRepository<Cart,Integer> {
	Cart findByCustomer(Customer cutomer);
    Cart findByCustomerAndPizzaToppings(Customer customer, PizzaToppings pt);
    Cart findByPizzaToppings(PizzaToppings pt);

 
}