package com.cg.pizza.service;

import java.util.List;

import com.cg.pizza.entity.OrderedPizza;

public interface OrderedPizzaService {
	public List<OrderedPizza> getPizzaByOrderId(int orderId); 
}
