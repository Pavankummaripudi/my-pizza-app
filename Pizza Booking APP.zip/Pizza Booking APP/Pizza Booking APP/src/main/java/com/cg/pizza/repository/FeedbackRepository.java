package com.cg.pizza.repository;
 
import java.util.List;
 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.FeedBack;
import com.cg.pizza.entity.Pizza;
 
@Repository
public interface FeedbackRepository extends JpaRepository<FeedBack, Integer>{
	@Query(value = "select f from FeedBack f where f.customer.customerId= :cid")
	List<FeedBack> searchByCustomerId(@Param("cid") int customerId);
	@Query(value = "select f from FeedBack f where f.pizza.pizzaId= :pid")
	List<FeedBack> searchByPizzaId(@Param("pid") int pizzaId);
	FeedBack findByCustomerAndPizza(Customer customer, Pizza pizza);
}