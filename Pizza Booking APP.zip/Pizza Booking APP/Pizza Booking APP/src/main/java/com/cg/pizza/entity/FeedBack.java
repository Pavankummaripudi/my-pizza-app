package com.cg.pizza.entity;
 
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
@Entity
public class FeedBack {
@Id
@GeneratedValue
    private int feedbackId;
    @ManyToOne
    @JoinColumn(name="pizzaId")
    private Pizza pizza;
    @ManyToOne
    @JoinColumn(name="customerId")
    private Customer customer;
    private int rating;
    private String feedback;
    public FeedBack() {
	}
 
	@Override
	public String toString() {
		return "FeedBack [feedbackId=" + feedbackId + ", customer=" + customer + ", pizza=" + pizza + ", rating="
				+ rating + ", feedback=" + feedback + "]";
	}

	public FeedBack(int ratingId, Customer customer, Pizza pizza, int rating, String feedback) {
		super();
		this.feedbackId = ratingId;
		this.customer = customer;
		this.pizza = pizza;
		this.rating = rating;
		this.feedback = feedback;
	}
 
	public int getFeedbackId() {
        return feedbackId;
    }
 
    public void setfeedbackId(int ratingId) {
        this.feedbackId = ratingId;
    }
 
    public Customer getCustomer() {
        return customer;
    }
 
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
 
    public Pizza getPizza() {
        return pizza;
    }
 
    public void setPizza(Pizza pizza) {
        this.pizza = pizza;
    }
 
    public int getRating() {
        return rating;
    }
 
    public void setRating(int rating) {
        this.rating = rating;
    }
 
    public String getFeedback() {
        return feedback;
    }
 
    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }
}