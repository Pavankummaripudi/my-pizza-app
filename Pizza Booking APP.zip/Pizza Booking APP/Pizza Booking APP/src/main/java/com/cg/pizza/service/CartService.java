package com.cg.pizza.service;
import java.util.List;

import com.cg.pizza.dto.CartDTO;
import com.cg.pizza.dto.PizzaToppingsDTO;
import com.cg.pizza.entity.Cart;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.PizzaToppings;
public interface CartService {
	public Cart addPizzatoCart(CartDTO cartDTO);
	public Cart getCartItemsByCustomerId(int customerId);
	public PizzaToppings updatePizzaQuantity(PizzaToppingsDTO ptDto);
	public void deleteCartItemsByCustomerId(int customerId);
	public void deletePizzafromCart(int pizzaId);
	public PizzaToppings addPizzaToppings(PizzaToppingsDTO ptDTO,int toppingId);
	public void deletePizzaToppings(int pizzaToppingId);
	public double getTotalOrderPrice(Customer c);
	public List<PizzaToppings> getAllPizzaToppings();
	
}