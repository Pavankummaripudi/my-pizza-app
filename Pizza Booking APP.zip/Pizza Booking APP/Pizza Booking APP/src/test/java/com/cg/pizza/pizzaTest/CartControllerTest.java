package com.cg.pizza.pizzaTest;

import com.cg.pizza.controller.CartController;
import com.cg.pizza.dto.CartDTO;
import com.cg.pizza.dto.PizzaToppingsDTO;
import com.cg.pizza.entity.Cart;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.PizzaToppings;
import com.cg.pizza.repository.CustomerRepo;
import com.cg.pizza.service.CartService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class CartControllerTest {

    private MockMvc mockMvc;

    @Mock
    private CartService cartService;

    @Mock
    private CustomerRepo customerRepository;

    @InjectMocks
    private CartController cartController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(cartController).build();
    }

    @Test
    public void testAddPizzatoCart() throws Exception {
        CartDTO cartDTO = new CartDTO();
        Principal principal = () -> "username";

        when(customerRepository.findByUsername("username")).thenReturn(new Customer());
        when(cartService.addPizzatoCart(cartDTO)).thenReturn(new Cart());

        mockMvc.perform(post("/cart")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}")
                .principal(principal))
                .andExpect(status().isOk());
    }

    @Test
    public void testUpdatePizzaQuantity() throws Exception {
        PizzaToppingsDTO pizzaToppingsDTO = new PizzaToppingsDTO();

        when(cartService.updatePizzaQuantity(pizzaToppingsDTO)).thenReturn(new PizzaToppings());

        mockMvc.perform(put("/cart")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}"))
                .andExpect(status().isOk());
    }

    @Test
    public void testDeleteCartItemsByCustomerId() throws Exception {
        mockMvc.perform(delete("/cart/{customerId}", 1)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetCartItemsByCustomerId() throws Exception {
        Principal principal = () -> "username";
        when(customerRepository.findByUsername("username")).thenReturn(new Customer());
        when(cartService.getCartItemsByCustomerId(anyInt())).thenReturn(new Cart());

        mockMvc.perform(get("/cart/pizza")
                .contentType(MediaType.APPLICATION_JSON)
                .principal(principal))
                .andExpect(status().isOk());
    }

    @Test
    public void testDeletePizzafromCart() throws Exception {
        mockMvc.perform(delete("/cart/deletePizza/{id}", 1)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testAddPizzaToppings() throws Exception {
        PizzaToppingsDTO pizzaToppingsDTO = new PizzaToppingsDTO();

        mockMvc.perform(post("/cart/{toppingId}", 1)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}"))
                .andExpect(status().isOk());
    }


    @Test
    public void testGetTotalOrderPrice() throws Exception {
        Principal principal = () -> "username";
        when(customerRepository.findByUsername("username")).thenReturn(new Customer());
        when(cartService.getTotalOrderPrice(any())).thenReturn(100.0);

        mockMvc.perform(get("/cart/orderprice")
                .contentType(MediaType.APPLICATION_JSON)
                .principal(principal))
                .andExpect(status().isOk())
                .andExpect(content().string("100.0"));
    }

    @Test
    public void testGetAllPizzaToppings() throws Exception {
        List<PizzaToppings> pizzaToppingsList = new ArrayList<>();
        when(cartService.getAllPizzaToppings()).thenReturn(pizzaToppingsList);

        mockMvc.perform(get("/cart/pizzaToppings")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}
