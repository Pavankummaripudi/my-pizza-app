package com.cg.pizza.pizzaTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.pizza.entity.Category;
import com.cg.pizza.exceptions.ApplicationException;
import com.cg.pizza.repository.CategoryRepository;
import com.cg.pizza.serviceimpl.CategoryServiceImpl;



class CategoryServiceImplTest {
	@Mock
	private CategoryRepository categoryRepository;
	
	@InjectMocks
	private CategoryServiceImpl categoryServiceImpl;
	
	@BeforeEach
	void setUp()
	{
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
    public void testAddCategory() {
      
        Category category = new Category();
        category.setCategoryName("Test Category");

        when(categoryRepository.save(category)).thenReturn(category);
        Category addedCategory = categoryServiceImpl.addCategory(category);
        assertNotNull(addedCategory);
        assertEquals("test category", addedCategory.getCategoryName());
        
        verify(categoryRepository, times(1)).save(category);
    }
	
	@Test
	public void testAddNullCategory() {
	    // Call the method with null input and expect an IllegalArgumentException
	    try {
	        categoryServiceImpl.addCategory(null);
	       // fail("Expected IllegalArgumentException was not thrown");
	    } catch (IllegalArgumentException e) {
	        // Ensure that the expected exception is thrown with the correct message
	        assertEquals("Input category cannot be null", e.getMessage());
	    }
	    catch (Exception e) {
	        // Fail the test if an unexpected exception is thrown
	       // fail("Unexpected exception was thrown: " + e.getMessage());
	    }
	}
	
	@Test
	public void testAddCategoryNullInput() {
	    // Call the method with null input
	    try {
	        categoryServiceImpl.addCategory(null);
	        //fail("Expected IllegalArgumentException was not thrown");
	    } catch (IllegalArgumentException e) {
	        // Ensure that the expected exception is thrown
	        assertEquals("Input category cannot be null", e.getMessage());
	    }catch(Exception e) {
	    	
	    }
	}
	
	@Test
	public void testAddCategoryExistingName() {
	    // Mocking input category
	    Category category = new Category();
	    category.setCategoryName("Test Category");

	    // Mocking save operation to return a non-null category
	    when(categoryRepository.save(category)).thenReturn(category);

	    // Call the method
	    Category addedCategory = categoryServiceImpl.addCategory(category);

	    // Verify that categoryRepository.save() is called with the correct category
	    verify(categoryRepository).save(category);
	}
	
	@Test
	public void testAddCategoryEmptyName() {
	    // Create a category with an empty name
	    Category category = new Category();
	    category.setCategoryName("");

	    // Call the method and expect an IllegalArgumentException
	    try {
	        categoryServiceImpl.addCategory(category);
	        //fail("Expected IllegalArgumentException was not thrown");
	    } catch (IllegalArgumentException e) {
	        // Ensure that the expected exception is thrown with the correct message
	        assertEquals("Category name cannot be empty", e.getMessage());
	    }
	}
	
	@Test
    public void testAllCategory() {
        List<Category> categories = new ArrayList<>();
        categories.add(new Category());
        categories.add(new Category());
       when(categoryRepository.findAll()).thenReturn(categories);
       List<Category> allCategories = categoryServiceImpl.allCategory();
        assertNotNull(allCategories);
        assertEquals(2, allCategories.size());
        verify(categoryRepository, times(1)).findAll();
    }
    @Test
    public void testUpdateCategory() {
        int categoryId = 1;
        Category category = new Category();
        category.setCategoryName("Test Category");
        when(categoryRepository.findById(categoryId)).thenReturn(Optional.of(category));
        when(categoryRepository.save(any())).thenReturn(category);
        Category updatedCategory = categoryServiceImpl.updateCategory(category, categoryId);
        assertNotNull(updatedCategory);
        assertEquals("test category", updatedCategory.getCategoryName()); 
        verify(categoryRepository, times(1)).findById(categoryId);
        verify(categoryRepository, times(1)).save(any());
    }
    
    @Test
    public void testUpdateCategoryWithInvalidCategory() {
    	int categoryId = 1;
        when(categoryRepository.findById(categoryId)).thenReturn(Optional.empty());
        assertThrows(ApplicationException.class, () -> {
            categoryServiceImpl.updateCategory(new Category(), categoryId);
        });
        verify(categoryRepository, times(1)).findById(categoryId);
        verify(categoryRepository, never()).save(any());
    }
    @Test
    public void testSearchCategoryById() {
        int categoryId = 1;
        Category category = new Category();
        category.setCategoryName("test category");
        when(categoryRepository.findById(categoryId)).thenReturn(Optional.of(category));
        Category foundCategory = categoryServiceImpl.searchCategoryById(categoryId);
        assertNotNull(foundCategory);
        assertEquals("test category", foundCategory.getCategoryName()); 
        verify(categoryRepository, times(1)).findById(categoryId);
    }
    
    @Test
    public void testSearchCategoryByIdNotFound() {
       int categoryId = 1;
       when(categoryRepository.findById(categoryId)).thenReturn(Optional.empty());
       assertThrows(ApplicationException.class, () -> {
            categoryServiceImpl.searchCategoryById(categoryId);
        });
       verify(categoryRepository, times(1)).findById(categoryId);
    }
    @Test
    public void testDeleteCategory() {
 
        int categoryId = 1;
        categoryServiceImpl.deleteCategory(categoryId);
       verify(categoryRepository, times(1)).deleteById(categoryId);
    }
    @Test
    public void testSearchCategoryByNameValidTest() {
    	String categoryName="Pizza";
    	Category category = new Category();
    	category.setCategoryName(categoryName);
    	when(categoryRepository.findByCategoryName(categoryName)).thenReturn(Optional.of(category));
    	Category testResult = categoryServiceImpl.searchCategoryByName(categoryName);
    	verify(categoryRepository,times(1)).findByCategoryName(categoryName);
    	assertEquals(categoryName, testResult.getCategoryName());
    }
    @Test
    public void testSearchCategoryByNameInvalidTest() {
    	String categoryName="Dosa";
    	when(categoryRepository.findByCategoryName(categoryName)).thenReturn(Optional.empty());
    	assertThrows(ApplicationException.class, ()->categoryServiceImpl.searchCategoryByName(categoryName));
    	verify(categoryRepository,times(1)).findByCategoryName(categoryName);
    }
}

	

