package com.cg.pizza.pizzaTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.pizza.dto.CartDTO;
import com.cg.pizza.dto.PizzaToppingsDTO;
import com.cg.pizza.entity.Cart;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.Pizza;
import com.cg.pizza.entity.PizzaToppings;
import com.cg.pizza.entity.Toppings;
import com.cg.pizza.exceptions.ApplicationException;
import com.cg.pizza.repository.CartRepository;
import com.cg.pizza.repository.CustomerRepo;
import com.cg.pizza.repository.PizzaRepository;
import com.cg.pizza.repository.PizzaToppingsRepository;
import com.cg.pizza.repository.ToppingsRepository;
import com.cg.pizza.serviceimpl.CartServiceImpl;

public class CartServiceImplTest {

    @Mock
    private PizzaRepository pizzaRepository;

    @Mock
    private CartRepository cartRepository;

    @Mock
    private CustomerRepo customerRepository;

    @Mock
    private ToppingsRepository toppingsRepository;

    @Mock
    private PizzaToppingsRepository ptRepo;

    @InjectMocks
    private CartServiceImpl cartService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddPizzatoCart_NewCart() {
        CartDTO cartDTO = new CartDTO();
        cartDTO.setCustomerId(1);
        cartDTO.setPizzaToppingId(1);

        Customer customer = new Customer();
        customer.setCustomerId(1);

        PizzaToppings pt = new PizzaToppings();
        pt.setPtId(1);

        when(customerRepository.findById(anyInt())).thenReturn(Optional.of(customer));
        when(ptRepo.findById(anyInt())).thenReturn(Optional.of(pt));
        when(cartRepository.findByCustomer(any(Customer.class))).thenReturn(null);
        when(cartRepository.save(any(Cart.class))).thenReturn(new Cart());

        Cart result = cartService.addPizzatoCart(cartDTO);

        assertNotNull(result);
        verify(customerRepository).findById(anyInt());
        verify(ptRepo).findById(anyInt());
        verify(cartRepository).findByCustomer(any(Customer.class));
        verify(cartRepository).save(any(Cart.class));
    }
    
    @Test
    public void testAddPizzatoCartCustomerNotFound() {
        // Mocking input DTO
        CartDTO cartDTO = new CartDTO();
        cartDTO.setCustomerId(1);
        cartDTO.setPizzaToppingId(1);

        // Mocking customer not found
        when(customerRepository.findById(1)).thenReturn(Optional.empty());

        // Call the method and assert that it throws ApplicationException
        ApplicationException exception = assertThrows(ApplicationException.class, () -> {
            cartService.addPizzatoCart(cartDTO);
        });

        // Verify the exception message if needed
        assertEquals("Customer not found", exception.getMessage());
    }
    

    @Test
    void testAddPizzatoCart_ExistingCart() {
        CartDTO cartDTO = new CartDTO();
        cartDTO.setCustomerId(1);
        cartDTO.setPizzaToppingId(1);

        Customer customer = new Customer();
        customer.setCustomerId(1);

        PizzaToppings pt = new PizzaToppings();
        pt.setPtId(1);

        Cart existingCart = new Cart();
        existingCart.setCustomer(customer);
        existingCart.setPizzaToppings(new ArrayList<>());

        when(customerRepository.findById(anyInt())).thenReturn(Optional.of(customer));
        when(ptRepo.findById(anyInt())).thenReturn(Optional.of(pt));
        when(cartRepository.findByCustomer(any(Customer.class))).thenReturn(existingCart);
        when(cartRepository.save(any(Cart.class))).thenReturn(existingCart);

        Cart result = cartService.addPizzatoCart(cartDTO);

        assertNotNull(result);
        assertEquals(1, result.getPizzaToppings().size());
        verify(customerRepository).findById(anyInt());
        verify(ptRepo).findById(anyInt());
        verify(cartRepository).findByCustomer(any(Customer.class));
        verify(cartRepository).save(any(Cart.class));
    }

    @Test
    void testGetCartItemsByCustomerId() {
        Customer customer = new Customer();
        customer.setCustomerId(1);

        Cart cart = new Cart();
        cart.setCustomer(customer);

        when(customerRepository.findById(anyInt())).thenReturn(Optional.of(customer));
        when(cartRepository.findByCustomer(any(Customer.class))).thenReturn(cart);

        Cart result = cartService.getCartItemsByCustomerId(1);

        assertNotNull(result);
        assertEquals(customer, result.getCustomer());
        verify(customerRepository).findById(anyInt());
        verify(cartRepository).findByCustomer(any(Customer.class));
    }
    
    @Test
    public void testGetCartItemsByCustomerIdCustomerNotFound() {
        // Mocking input customerId
        int customerId = 1;

        // Mocking customer not found
        when(customerRepository.findById(customerId)).thenReturn(Optional.empty());

        // Call the method and manually assert the ApplicationException
        try {
            cartService.getCartItemsByCustomerId(customerId);
            fail("Expected ApplicationException was not thrown");
        } catch (ApplicationException e) {
            // Check if the correct exception is thrown
            assertEquals("Customer Not Found", e.getMessage());
        }
    }

    
    @Test
    void testUpdatePizzaQuantity() {
        PizzaToppingsDTO ptDTO = new PizzaToppingsDTO();
        ptDTO.setPizzaId(1);

        Pizza pizza = new Pizza();
        pizza.setPizzaId(1);

        PizzaToppings pt = new PizzaToppings();
        pt.setPizza(pizza);

        when(pizzaRepository.findByPizzaId(anyInt())).thenReturn(pizza);
        when(ptRepo.findByPizza(any(Pizza.class))).thenReturn(pt);
        when(ptRepo.save(any(PizzaToppings.class))).thenReturn(pt);

        PizzaToppings result = cartService.updatePizzaQuantity(ptDTO);

        assertNotNull(result);
        verify(pizzaRepository).findByPizzaId(anyInt());
        verify(ptRepo).findByPizza(any(Pizza.class));
        verify(ptRepo).save(any(PizzaToppings.class));
    }
    
//    @Test
//    public void testUpdatePizzaQuantityPizzaNotFound() {
//        // Mocking input DTO
//        PizzaToppingsDTO ptDTO = new PizzaToppingsDTO();
//        ptDTO.setPizzaId(1);
//        ptDTO.setPizzaQuantity(5); // Or any quantity value you prefer
//
//        // Mocking findByPizza returning null
//        when(pizzaRepository.findByPizzaId(ptDTO.getPizzaId())).thenReturn(null);
//
//        // Call the method
//        cartService.updatePizzaQuantity(ptDTO);
//
//        // Verify that ptRepo.save() is not called
//        verify(ptRepo, never()).save(any(PizzaToppings.class));
//    }

//    @Test
//    public void testUpdatePizzaQuantityPizzaToppingsNotFound() {
//        // Mocking input DTO
//        PizzaToppingsDTO ptDTO = new PizzaToppingsDTO();
//        ptDTO.setPizzaId(1);
//        ptDTO.setPizzaQuantity(5); // Or any quantity value you prefer
//
//        // Mocking findByPizza returning a pizza
//        Pizza pizza = new Pizza();
//        when(pizzaRepository.findByPizzaId(ptDTO.getPizzaId())).thenReturn(pizza);
//
//        // Mocking findByPizza returning null
//        when(ptRepo.findByPizza(pizza)).thenReturn(null);
//
//        // Call the method
//        cartService.updatePizzaQuantity(ptDTO);
//
//        // Verify that ptRepo.save() is not called
//        verify(ptRepo, never()).save(any(PizzaToppings.class));
//    }
//    
    @Test
    void testDeleteCartItemsByCustomerId() {
        Customer customer = new Customer();
        customer.setCustomerId(1);

        Cart cart = new Cart();
        cart.setCustomer(customer);

        when(customerRepository.findById(anyInt())).thenReturn(Optional.of(customer));
        when(cartRepository.findByCustomer(any(Customer.class))).thenReturn(cart);
        doNothing().when(cartRepository).delete(any(Cart.class));

        cartService.deleteCartItemsByCustomerId(1);

        verify(customerRepository).findById(anyInt());
        verify(cartRepository).findByCustomer(any(Customer.class));
        verify(cartRepository).delete(any(Cart.class));
    }
    
    
    @Test
    void testDeletePizzafromCart() {
        doNothing().when(cartRepository).deleteById(anyInt());

        cartService.deletePizzafromCart(1);

        verify(cartRepository).deleteById(anyInt());
    }
    
    @Test
    void testGetTotalOrderPrice() {
        // Mock data
        Customer customer = new Customer();
        customer.setCustomerId(1);

        Pizza pizza = new Pizza();
        pizza.setPizzaPrice(10.0);

        Toppings topping1 = new Toppings();
        topping1.setToppingPrice(2.0);

        Toppings topping2 = new Toppings();
        topping2.setToppingPrice(3.0);

        PizzaToppings pizzaToppings = new PizzaToppings();
        pizzaToppings.setPizza(pizza);
        pizzaToppings.setToppings(List.of(topping1, topping2));
        pizzaToppings.setPizzaQuantity(2);

        Cart cart = new Cart();
        cart.setCustomer(customer);
        cart.setPizzaToppings(List.of(pizzaToppings));

        // Mock behavior
        when(cartRepository.findByCustomer(any(Customer.class))).thenReturn(cart);

        // Actual call
        double totalOrderPrice = cartService.getTotalOrderPrice(customer);

        // Calculate expected total
        double expectedTotal = (pizza.getPizzaPrice() * pizzaToppings.getPizzaQuantity()) 
                              + topping1.getToppingPrice() 
                              + topping2.getToppingPrice();

        // Assertions
        assertEquals(expectedTotal, totalOrderPrice, 0.01); // Allowing a small delta for floating point comparison
    }


    @Test
    void testAddPizzaToppings_NewPizzaToppings() {
        PizzaToppingsDTO ptDTO = new PizzaToppingsDTO();
        ptDTO.setPizzaId(1);

        Pizza pizza = new Pizza();
        pizza.setPizzaId(1);

        Toppings topping = new Toppings();
        topping.setToppingId(1);

        when(pizzaRepository.findByPizzaId(anyInt())).thenReturn(pizza);
        when(toppingsRepository.findById(anyInt())).thenReturn(Optional.of(topping));
        when(ptRepo.findByPizza(any(Pizza.class))).thenReturn(null);
        when(ptRepo.save(any(PizzaToppings.class))).thenReturn(new PizzaToppings());

        PizzaToppings result = cartService.addPizzaToppings(ptDTO, 1);

        assertNotNull(result);
        verify(pizzaRepository).findByPizzaId(anyInt());
        verify(toppingsRepository).findById(anyInt());
        verify(ptRepo).findByPizza(any(Pizza.class));
        verify(ptRepo).save(any(PizzaToppings.class));
    }
    
    
    @Test
    void testAddPizzaToppings_ExistingPizzaToppings() {
        PizzaToppingsDTO ptDTO = new PizzaToppingsDTO();
        ptDTO.setPizzaId(1);

        Pizza pizza = new Pizza();
        pizza.setPizzaId(1);

        Toppings topping = new Toppings();
        topping.setToppingId(1);

        PizzaToppings pt = new PizzaToppings();
        pt.setPizza(pizza);
        pt.setToppings(new ArrayList<>());

        when(pizzaRepository.findByPizzaId(anyInt())).thenReturn(pizza);
        when(toppingsRepository.findById(anyInt())).thenReturn(Optional.of(topping));
        when(ptRepo.findByPizza(any(Pizza.class))).thenReturn(pt);
        when(ptRepo.save(any(PizzaToppings.class))).thenReturn(pt);

        PizzaToppings result = cartService.addPizzaToppings(ptDTO, 1);

        assertNotNull(result);
        verify(pizzaRepository).findByPizzaId(anyInt());
        verify(toppingsRepository).findById(anyInt());
        verify(ptRepo).findByPizza(any(Pizza.class));
        verify(ptRepo).save(any(PizzaToppings.class));
    }

    @Test
    void testDeletePizzaToppings() {
        doNothing().when(ptRepo).deleteById(anyInt());

        cartService.deletePizzaToppings(1);

        verify(ptRepo).deleteById(anyInt());
    }

    @Test
    void testGetAllPizzaToppings() {
        List<PizzaToppings> pizzaToppingsList = new ArrayList<>();
        when(ptRepo.findAll()).thenReturn(pizzaToppingsList);

        List<PizzaToppings> result = cartService.getAllPizzaToppings();

        assertNotNull(result);
        assertEquals(pizzaToppingsList, result);
        verify(ptRepo).findAll();
    }
}

