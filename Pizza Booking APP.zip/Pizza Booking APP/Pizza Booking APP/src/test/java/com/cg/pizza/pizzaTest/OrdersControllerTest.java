package com.cg.pizza.pizzaTest;


import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import com.cg.pizza.controller.OrdersController;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.Orders;
import com.cg.pizza.repository.CustomerRepo;
import com.cg.pizza.service.OrdersService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class OrdersControllerTest {

    private MockMvc mockMvc;

    @Mock
    private OrdersService ordersService;

    @Mock
    private CustomerRepo customerRepository;

    @InjectMocks
    private OrdersController ordersController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(ordersController).build();
    }

    @Test
    public void testGetAllOrders() throws Exception {
        List<Orders> ordersList = new ArrayList<>();
        when(ordersService.findAll()).thenReturn(ordersList);

        mockMvc.perform(get("/orders")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testAddOrder() throws Exception {
        Principal mockPrincipal = mock(Principal.class);
        when(mockPrincipal.getName()).thenReturn("testUser");

        Customer customer = new Customer();
        customer.setCustomerId(1);
        when(customerRepository.findByUsername("testUser")).thenReturn(customer);

        mockMvc.perform(post("/orders")
                .principal(mockPrincipal)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetAllOrdersByCustomerId() throws Exception {
        Principal mockPrincipal = mock(Principal.class);
        when(mockPrincipal.getName()).thenReturn("testUser");

        Customer customer = new Customer();
        customer.setCustomerId(1);
        when(customerRepository.findByUsername("testUser")).thenReturn(customer);

        List<Orders> ordersList = new ArrayList<>();
        when(ordersService.getOrdersByCustomerId(1)).thenReturn(ordersList);

        mockMvc.perform(get("/orders/cust")
                .principal(mockPrincipal)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetAllOrdersByCustomerNumber() throws Exception {
        List<Orders> ordersList = new ArrayList<>();
        when(ordersService.getOrdersByCustomerNumber("1234567890")).thenReturn(ordersList);

        mockMvc.perform(get("/orders/mobileno/1234567890")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testCancelOrder() throws Exception {
        Orders order = new Orders();
        when(ordersService.cancelOrder(1)).thenReturn(order);

        mockMvc.perform(delete("/orders/cancel/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testUpdateOrderStatus() throws Exception {
        Orders order = new Orders();
        when(ordersService.updateOrderStatus(1)).thenReturn(order);

        mockMvc.perform(put("/orders/status/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}
