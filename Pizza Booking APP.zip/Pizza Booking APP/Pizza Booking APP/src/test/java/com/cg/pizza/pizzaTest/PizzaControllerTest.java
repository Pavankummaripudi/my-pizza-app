package com.cg.pizza.pizzaTest;


import java.util.ArrayList;
import java.util.List;

import com.cg.pizza.controller.PizzaController;
import com.cg.pizza.dto.PizzaDTO;
import com.cg.pizza.entity.Pizza;
import com.cg.pizza.service.PizzaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class PizzaControllerTest {

    private MockMvc mockMvc;

    @Mock
    private PizzaService pizzaService;

    @InjectMocks
    private PizzaController pizzaController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(pizzaController).build();
    }

    @Test
    public void testAddPizza() throws Exception {
        PizzaDTO pizzaDTO = new PizzaDTO();
        Pizza pizza = new Pizza();
        when(pizzaService.addPizza(pizzaDTO)).thenReturn(pizza);

        mockMvc.perform(post("/pizza")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}"))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetByPizzaId() throws Exception {
        Pizza pizza = new Pizza();
        when(pizzaService.getByPizzaId(1)).thenReturn(pizza);

        mockMvc.perform(get("/pizza/id/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetByPizzaSize() throws Exception {
        List<Pizza> pizzaList = new ArrayList<>();
        when(pizzaService.getPizzaBySize("Large")).thenReturn(pizzaList);

        mockMvc.perform(get("/pizza/size/Large")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testFindAll() throws Exception {
        List<Pizza> pizzaList = new ArrayList<>();
        when(pizzaService.findAll()).thenReturn(pizzaList);

        mockMvc.perform(get("/pizza")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testUpdatePizza() throws Exception {
        PizzaDTO pizzaDTO = new PizzaDTO();
        Pizza pizza = new Pizza();
        when(pizzaService.updatePizza(1, pizzaDTO)).thenReturn(pizza);

        mockMvc.perform(put("/pizza/update/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}"))
                .andExpect(status().isOk());
    }

    @Test
    public void testDeletePizza() throws Exception {
        mockMvc.perform(delete("/pizza/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetPizzaByCategoryId() throws Exception {
        List<Pizza> pizzaList = new ArrayList<>();
        when(pizzaService.getPizzaByCategoryId(1)).thenReturn(pizzaList);

        mockMvc.perform(get("/pizza/categoryid/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetPizzaByCategoryName() throws Exception {
        List<Pizza> pizzaList = new ArrayList<>();
        when(pizzaService.getPizzaByCategoryName("Vegetarian")).thenReturn(pizzaList);

        mockMvc.perform(get("/pizza/categoryname/Vegetarian")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetPizzaByName() throws Exception {
        Pizza pizza = new Pizza();
        when(pizzaService.getPizzaByName("Margherita")).thenReturn(pizza);

        mockMvc.perform(get("/pizza/pizzaname/Margherita")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}

