package com.cg.pizza.pizzaTest;


import java.util.ArrayList;
import java.util.List;

import com.cg.pizza.controller.CategoryController;
import com.cg.pizza.entity.Category;
import com.cg.pizza.service.CategoryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class CategoryControllerTest {

    private MockMvc mockMvc;

    @Mock
    private CategoryService categoryService;

    @InjectMocks
    private CategoryController categoryController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(categoryController).build();
    }

    @Test
    public void testGetAllCategories() throws Exception {
        List<Category> categories = new ArrayList<>();
        when(categoryService.allCategory()).thenReturn(categories);

        mockMvc.perform(get("/category")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testAddCategory() throws Exception {
        Category category = new Category();
        when(categoryService.addCategory(category)).thenReturn(category);

        mockMvc.perform(post("/category")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}"))
                .andExpect(status().isOk());
    }

    @Test
    public void testSearchById() throws Exception {
        Category category = new Category();
        when(categoryService.searchCategoryById(1)).thenReturn(category);

        mockMvc.perform(get("/category/{categoryId}", 1)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testUpdateCategory() throws Exception {
        Category category = new Category();
        when(categoryService.updateCategory(category, 1)).thenReturn(category);

        mockMvc.perform(put("/category/{categoryId}", 1)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}"))
                .andExpect(status().isOk());
    }

    @Test
    public void testDeleteCategory() throws Exception {
        mockMvc.perform(delete("/category/{categoryId}", 1)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testSearchByName() throws Exception {
        Category category = new Category();
        when(categoryService.searchCategoryByName("test")).thenReturn(category);

        mockMvc.perform(get("/category/name/{categoryName}", "test")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}

