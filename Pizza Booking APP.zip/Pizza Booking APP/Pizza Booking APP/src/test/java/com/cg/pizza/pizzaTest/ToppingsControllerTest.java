package com.cg.pizza.pizzaTest;

import java.util.ArrayList;
import java.util.List;

import com.cg.pizza.controller.ToppingsController;
import com.cg.pizza.dto.ToppingsDTO;
import com.cg.pizza.entity.Toppings;
import com.cg.pizza.serviceimpl.ToppingsServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class ToppingsControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ToppingsServiceImpl toppingsService;

    @InjectMocks
    private ToppingsController toppingsController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(toppingsController).build();
    }

    @Test
    public void testAddNewToppings() throws Exception {
        ToppingsDTO toppingsDTO = new ToppingsDTO();
        when(toppingsService.addToppings(toppingsDTO)).thenReturn(toppingsDTO);

        mockMvc.perform(post("/toppings/addToppings")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}"))
                .andExpect(status().isOk());
    }

    @Test
    public void testUpdateToppings() throws Exception {
        when(toppingsService.updateToppings(1, new ToppingsDTO())).thenReturn("Updated Successfully");

        mockMvc.perform(put("/toppings/updateToppings/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}"))
                .andExpect(status().isOk());
    }

    @Test
    public void testDeleteToppings() throws Exception {
        when(toppingsService.removeToppings(1)).thenReturn("Deleted Successfully");

        mockMvc.perform(delete("/toppings/deleteToppings/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetToppingsById() throws Exception {
        ToppingsDTO toppingsDTO = new ToppingsDTO();
        when(toppingsService.searchToppingsById(1)).thenReturn(toppingsDTO);

        mockMvc.perform(get("/toppings/getToppingsUsingId/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetAllToppings() throws Exception {
        List<Toppings> toppingsList = new ArrayList<>();
        when(toppingsService.getAllToppings()).thenReturn(toppingsList);

        mockMvc.perform(get("/toppings")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}

