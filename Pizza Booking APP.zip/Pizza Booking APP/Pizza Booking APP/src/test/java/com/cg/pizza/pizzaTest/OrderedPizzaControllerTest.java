package com.cg.pizza.pizzaTest;

import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import com.cg.pizza.controller.OrderedPizzaController;
import com.cg.pizza.entity.OrderedPizza;
import com.cg.pizza.service.OrderedPizzaService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@ExtendWith(MockitoExtension.class)
public class OrderedPizzaControllerTest {

    @Mock
    private OrderedPizzaService orderedPizzaService;

    @InjectMocks
    private OrderedPizzaController orderedPizzaController;

    @Test
    public void testGetPizzaByOrderId() throws Exception {
        // Mock data
        List<OrderedPizza> orderedPizzas = new ArrayList<>();
        // Add some ordered pizzas to the list
        // ...

        // Mock the service method to return the list of ordered pizzas
        when(orderedPizzaService.getPizzaByOrderId(1)).thenReturn(orderedPizzas);

        // Setup MockMvc
        MockMvc mockMvc = MockMvcBuilders.standaloneSetup(orderedPizzaController).build();

        // Perform GET request
        mockMvc.perform(MockMvcRequestBuilders.get("/ordereditems/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.size()").value(orderedPizzas.size()));
    }
}

