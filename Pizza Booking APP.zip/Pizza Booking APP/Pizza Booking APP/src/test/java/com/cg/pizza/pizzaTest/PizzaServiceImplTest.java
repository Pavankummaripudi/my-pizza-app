package com.cg.pizza.pizzaTest;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.pizza.dto.PizzaDTO;
import com.cg.pizza.entity.Category;
import com.cg.pizza.entity.Pizza;
import com.cg.pizza.exceptions.ApplicationException;
import com.cg.pizza.repository.CategoryRepository;
import com.cg.pizza.repository.PizzaRepository;
import com.cg.pizza.repository.ToppingsRepository;
import com.cg.pizza.serviceimpl.PizzaServiceImpl;

public class PizzaServiceImplTest {

    @Mock
    private PizzaRepository pizzaRepository;

    @Mock
    private CategoryRepository categoryRepository;

    @Mock
    private ToppingsRepository toppingsRepo;

    @InjectMocks
    private PizzaServiceImpl pizzaService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddPizza() {
        PizzaDTO pizzaDTO = new PizzaDTO();
        pizzaDTO.setCategoryId(1);
        pizzaDTO.setPizzaName("Margherita");
        pizzaDTO.setPizzaSize("Large");
        pizzaDTO.setPizzaPrice(10.0);

        Category category = new Category();
        category.setCategoryId(1);
        category.setCategoryName("Veg");

        when(categoryRepository.findById(anyInt())).thenReturn(Optional.of(category));
        when(pizzaRepository.save(any(Pizza.class))).thenReturn(new Pizza());

        Pizza result = pizzaService.addPizza(pizzaDTO);

        assertNotNull(result);
        verify(categoryRepository).findById(anyInt());
        verify(pizzaRepository).save(any(Pizza.class));
    }

    @Test
    void testGetByPizzaId() {
        Pizza pizza = new Pizza();
        pizza.setPizzaId(1);

        when(pizzaRepository.findById(anyInt())).thenReturn(Optional.of(pizza));

        Pizza result = pizzaService.getByPizzaId(1);

        assertNotNull(result);
        verify(pizzaRepository).findById(anyInt());
    }

    @Test
    void testUpdatePizza() {
        PizzaDTO pizzaDTO = new PizzaDTO();
        pizzaDTO.setPizzaName("Margherita");
        pizzaDTO.setPizzaSize("Large");
        pizzaDTO.setPizzaPrice(10.0);

        Pizza pizza = new Pizza();
        pizza.setPizzaId(1);

        when(pizzaRepository.findById(anyInt())).thenReturn(Optional.of(pizza));
        when(pizzaRepository.save(any(Pizza.class))).thenReturn(pizza);

        Pizza result = pizzaService.updatePizza(1, pizzaDTO);

        assertNotNull(result);
        assertEquals(pizza.getPizzaName(), "margherita");
        verify(pizzaRepository).findById(anyInt());
        verify(pizzaRepository).save(any(Pizza.class));
    }

    @Test
    void testDeletePizza() {
        doNothing().when(pizzaRepository).deleteById(anyInt());

        pizzaService.deletePizza(1);

        verify(pizzaRepository).deleteById(anyInt());
    }

    @Test
    void testFindAll() {
        when(pizzaRepository.findAll()).thenReturn(Arrays.asList(new Pizza()));

        List<Pizza> result = pizzaService.findAll();

        assertNotNull(result);
        assertFalse(result.isEmpty());
        verify(pizzaRepository).findAll();
    }

    @Test
    void testGetPizzaByCategoryId() {
        Category category = new Category();
        category.setCategoryId(1);

        when(categoryRepository.findById(anyInt())).thenReturn(Optional.of(category));
        when(pizzaRepository.findByCategory(any(Category.class))).thenReturn(Arrays.asList(new Pizza()));

        List<Pizza> result = pizzaService.getPizzaByCategoryId(1);

        assertNotNull(result);
        assertFalse(result.isEmpty());
        verify(categoryRepository).findById(anyInt());
        verify(pizzaRepository).findByCategory(any(Category.class));
    }

    @Test
    void testGetPizzaByCategoryName() {
        Category category = new Category();
        category.setCategoryName("Veg");

        when(categoryRepository.findByCategoryName(anyString())).thenReturn(Optional.of(category));
        when(pizzaRepository.findByCategory(any(Category.class))).thenReturn(Arrays.asList(new Pizza()));

        List<Pizza> result = pizzaService.getPizzaByCategoryName("Veg");

        assertNotNull(result);
        assertFalse(result.isEmpty());
        verify(categoryRepository).findByCategoryName(anyString());
        verify(pizzaRepository).findByCategory(any(Category.class));
    }

    @Test
    void testGetPizzaBySize() {
        when(pizzaRepository.findAllByPizzaSize(anyString())).thenReturn(Arrays.asList(new Pizza()));

        List<Pizza> result = pizzaService.getPizzaBySize("Large");

        assertNotNull(result);
        assertFalse(result.isEmpty());
        verify(pizzaRepository).findAllByPizzaSize(anyString());
    }

    @Test
    void testGetPizzaByName() {
        Pizza pizza = new Pizza();
        pizza.setPizzaName("Margherita");

        when(pizzaRepository.findByPizzaName(anyString())).thenReturn(pizza);

        Pizza result = pizzaService.getPizzaByName("Margherita");

        assertNotNull(result);
        assertEquals("Margherita", result.getPizzaName());
        verify(pizzaRepository).findByPizzaName(anyString());
    }
}
