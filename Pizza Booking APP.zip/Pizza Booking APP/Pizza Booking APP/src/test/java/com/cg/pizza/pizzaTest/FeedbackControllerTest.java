package com.cg.pizza.pizzaTest;
import com.cg.pizza.controller.FeedbackController;
import com.cg.pizza.dto.FeedbackDTO;
import com.cg.pizza.entity.FeedBack;
import com.cg.pizza.service.FeedbackService;
import com.cg.pizza.serviceimpl.CustomerServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import java.util.ArrayList;
import java.util.List;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class FeedbackControllerTest {

    private MockMvc mockMvc;

    @Mock
    private FeedbackService feedbackService;

    @Mock
    private CustomerServiceImpl customerService;

    @InjectMocks
    private FeedbackController feedbackController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(feedbackController).build();
    }

    @Test
    public void testGetFeedback() throws Exception {
        when(feedbackService.getFeedback(1)).thenReturn(new FeedBack());

        mockMvc.perform(get("/feedback/{feedbackId}", 1)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetAllFeedback() throws Exception {
        List<FeedBack> feedbackList = new ArrayList<>();
        when(feedbackService.getAllFeedback()).thenReturn(feedbackList);

        mockMvc.perform(get("/feedback")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testDeleteFeedback() throws Exception {
        mockMvc.perform(delete("/feedback/{feedbackId}", 1)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testUpdateFeedback() throws Exception {
        FeedbackDTO feedbackDto = new FeedbackDTO();
        when(feedbackService.updateFeedback(feedbackDto)).thenReturn(new FeedBack());

        mockMvc.perform(put("/feedback")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}"))
                .andExpect(status().isOk());
    }


    @Test
    public void testSearchByDoctorId() throws Exception {
        List<FeedBack> feedbackList = new ArrayList<>();
        when(feedbackService.searchByPizzaIdService(1)).thenReturn(feedbackList);

        mockMvc.perform(get("/feedback/searchPizza/{pizzaId}", 1)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}
