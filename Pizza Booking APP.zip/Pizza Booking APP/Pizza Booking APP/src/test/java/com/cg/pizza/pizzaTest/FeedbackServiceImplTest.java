package com.cg.pizza.pizzaTest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.cg.pizza.dto.FeedbackDTO;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.FeedBack;
import com.cg.pizza.entity.Pizza;
import com.cg.pizza.repository.CustomerRepo;
import com.cg.pizza.repository.FeedbackRepository;
import com.cg.pizza.repository.PizzaRepository;
import com.cg.pizza.serviceimpl.FeedbackServiceImpl;

@ExtendWith(MockitoExtension.class)
class FeedbackServiceImplTest {

    @Mock
    FeedbackRepository feedbackRepository;

    @Mock
    CustomerRepo customerRepository;

    @Mock
    PizzaRepository pizzaRepository;

    @InjectMocks
    FeedbackServiceImpl feedbackService;

    @Test
    void testAddFeedback() {
        FeedbackDTO feedbackDto = new FeedbackDTO();
        feedbackDto.setPizzaId(1);
        feedbackDto.setCustomerId(1);
        feedbackDto.setFeedback("Great pizza!");
        feedbackDto.setRating(5);

        Pizza pizza = new Pizza();
        pizza.setPizzaId(1);
        Customer customer = new Customer();
        customer.setCustomerId(1);
        FeedBack feedback = new FeedBack();
        feedback.setfeedbackId(1);
        
        when(pizzaRepository.findById(1)).thenReturn(Optional.of(pizza));
        when(customerRepository.findById(1)).thenReturn(Optional.of(customer));
        when(feedbackRepository.save(any(FeedBack.class))).thenReturn(feedback);
        
        FeedBack result = feedbackService.addFeedback(feedbackDto);
        assertEquals(feedback.getFeedbackId(), result.getFeedbackId());
    }

    @Test
    void testGetFeedback() {
        FeedBack feedback = new FeedBack();
        feedback.setfeedbackId(1);
        when(feedbackRepository.findById(1)).thenReturn(Optional.of(feedback));
        FeedBack result = feedbackService.getFeedback(1);
        assertEquals(feedback.getFeedbackId(), result.getFeedbackId());
    }
    
    @Test
    public void testDeleteFeedback() {
       int feedbackIdToDelete = 2;
 
        FeedBack existingFeedback = new FeedBack();
		existingFeedback.setfeedbackId(feedbackIdToDelete);
        when(feedbackRepository.findById(feedbackIdToDelete)).thenReturn(Optional.of(existingFeedback));
 
        // Execute the method
        feedbackService.deleteFeedback(feedbackIdToDelete);
        verify(feedbackRepository, times(1)).deleteById(feedbackIdToDelete);
 
        Optional<FeedBack> deletedFeedback = feedbackRepository.findById(feedbackIdToDelete);
        assertFalse(deletedFeedback.empty(), deletedFeedback, "Feedback should have been deleted");
    }
    
    private void assertFalse(Optional<Object> empty, Optional<FeedBack> deletedFeedback, String string) {
		// TODO Auto-generated method stub
		
	}

	@Test
    void testSearchByCustomerIdService() {
        int customerId = 1;

        // Create sample feedback objects
        FeedBack feedback1 = new FeedBack();
        // Set necessary properties for feedback1

        FeedBack feedback2 = new FeedBack();
        // Set necessary properties for feedback2

        List<FeedBack> feedbackList = new ArrayList<>();
        feedbackList.add(feedback1);
        feedbackList.add(feedback2);

        // Mock the behavior of the feedbackRepository
        when(feedbackRepository.searchByCustomerId(customerId)).thenReturn(feedbackList);

        // Call the method to be tested
        List<FeedBack> result = feedbackService.searchByCustomerIdService(customerId);

        // Verify the result
        assertEquals(feedbackList.size(), result.size());
        // You may also check other properties of the feedback objects if needed
    }
    
    @Test
    void testSearchByPizzaIdService() {
        int pizzaId = 1;

        // Create sample feedback objects
        FeedBack feedback1 = new FeedBack();
        // Set necessary properties for feedback1

        FeedBack feedback2 = new FeedBack();
        // Set necessary properties for feedback2

        List<FeedBack> feedbackList = new ArrayList<>();
        feedbackList.add(feedback1);
        feedbackList.add(feedback2);

        // Mock the behavior of the feedbackRepository
        when(feedbackRepository.searchByPizzaId(pizzaId)).thenReturn(feedbackList);

        // Call the method to be tested
        List<FeedBack> result = feedbackService.searchByPizzaIdService(pizzaId);

        // Verify the result
        assertEquals(feedbackList.size(), result.size());
        // You may also check other properties of the feedback objects if needed
    }
    @Test
    void testGetAllFeedback() {
        // Create sample feedback objects
        FeedBack feedback1 = new FeedBack();
        // Set necessary properties for feedback1

        FeedBack feedback2 = new FeedBack();
        // Set necessary properties for feedback2

        List<FeedBack> feedbackList = new ArrayList<>();
        feedbackList.add(feedback1);
        feedbackList.add(feedback2);

        // Mock the behavior of the feedbackRepository
        when(feedbackRepository.findAll()).thenReturn(feedbackList);

        // Call the method to be tested
        List<FeedBack> result = feedbackService.getAllFeedback();

        // Verify the result
        assertEquals(feedbackList.size(), result.size());
        // You may also check other properties of the feedback objects if needed
    }
    
//    @Test
//    public void testUpdateFeedback() {
//        // Mocking input DTO
//        FeedbackDTO feedbackDto = new FeedbackDTO();
//        feedbackDto.setFeedbackId(1);
//        feedbackDto.setPizzaId(1);
//        feedbackDto.setCustomerId(1);
//
//        // Mocking existing feedback
//        FeedBack existingFeedback = new FeedBack();
//        when(feedbackRepository.findById(1)).thenReturn(Optional.of(existingFeedback));
//
//        // Mocking Pizza and Customer
//        Pizza pizza = new Pizza();
//        Customer customer = new Customer();
//        when(pizzaRepository.findById(1)).thenReturn(Optional.of(pizza));
//        when(customerRepository.findById(1)).thenReturn(Optional.of(customer));
//
//        // Mocking save operation
//        when(feedbackRepository.save(any(FeedBack.class))).thenReturn(existingFeedback);
//
//        // Call the method
//        FeedBack updatedFeedback = feedbackService.updateFeedback(feedbackDto);
//
//        // Verify that save method is called
//        verify(feedbackRepository).save(any(FeedBack.class));
//
//        // Assertions
//        assertNotNull(updatedFeedback);
//        assertEquals(existingFeedback, updatedFeedback);
//    }

//    @Test
//    public void testUpdateFeedbackFeedbackNotPresent() {
//        // Mocking input DTO
//        FeedbackDTO feedbackDto = new FeedbackDTO();
//        feedbackDto.setFeedbackId(1);
//
//        // Mocking non-existing feedback
//        when(feedbackRepository.findById(1)).thenReturn(Optional.empty());
//
//        // Call the method
//        FeedBack updatedFeedback = feedbackService.updateFeedback(feedbackDto);
//
//        // Verify that save method is not called
//        verify(feedbackRepository, never()).save(any(FeedBack.class));
//
//        // Assertions
//        assertNull(updatedFeedback);
//    }
}
