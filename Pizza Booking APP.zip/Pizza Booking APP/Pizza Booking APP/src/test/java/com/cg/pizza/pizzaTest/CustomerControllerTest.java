package com.cg.pizza.pizzaTest;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import com.cg.pizza.controller.CustomerController;
import com.cg.pizza.dto.CustomerDTO;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.repository.CustomerRepo;
import com.cg.pizza.service.CustomerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class CustomerControllerTest {

    private MockMvc mockMvc;

    @Mock
    private CustomerService customerService;

    @Mock
    private CustomerRepo customerRepository;

    @InjectMocks
    private CustomerController customerController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(customerController).build();
    }

    @Test
    public void testGetAllCustomers() throws Exception {
        List<Customer> customers = new ArrayList<>();
        when(customerService.getAll()).thenReturn(customers);

        mockMvc.perform(get("/customer")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetCustomerByEmail() throws Exception {
        Customer customer = new Customer();
        when(customerService.getByEmail("test@example.com")).thenReturn(customer);

        mockMvc.perform(get("/customer/email/{email}", "test@example.com")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testAddCustomerDetails() throws Exception {
        CustomerDTO customerDTO = new CustomerDTO();
        Customer customer = new Customer();
        Principal principal = () -> "testuser";

        when(customerService.addCustomerDetails(customerDTO)).thenReturn(customer);

        mockMvc.perform(post("/customer")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}")
                .principal(principal))
                .andExpect(status().isOk());
    }

    @Test
    public void testUpdateCustomerDetails() throws Exception {
        CustomerDTO customerDTO = new CustomerDTO();
        Customer customer = new Customer();
        customer.setCustomerId(1);
        Principal principal = () -> "testuser";

        when(customerRepository.findByUsername("testuser")).thenReturn(customer);
        when(customerService.updateCustomerDetails(customerDTO)).thenReturn(customer);

        mockMvc.perform(put("/customer")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}")
                .principal(principal))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetCustomerById() throws Exception {
        Customer customer = new Customer();
        when(customerService.getByCustomerId(1)).thenReturn(customer);

        mockMvc.perform(get("/customer/{customerId}", 1)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetCustomerByUsername() throws Exception {
        Customer customer = new Customer();
        Principal principal = () -> "testuser";
        when(customerRepository.findByUsername("testuser")).thenReturn(customer);

        mockMvc.perform(get("/customer/username")
                .contentType(MediaType.APPLICATION_JSON)
                .principal(principal))
                .andExpect(status().isOk());
    }
}

