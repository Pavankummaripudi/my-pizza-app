package com.cg.pizza.pizzaTest;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.pizza.dto.OrdersDTO;
import com.cg.pizza.entity.Cart;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.Pizza;
import com.cg.pizza.entity.PizzaToppings;
import com.cg.pizza.entity.OrderedPizza;
import com.cg.pizza.entity.Orders;
import com.cg.pizza.exceptions.ApplicationException;
import com.cg.pizza.repository.CartRepository;
import com.cg.pizza.repository.CustomerRepo;
import com.cg.pizza.repository.OrderedPizzaRepository;
import com.cg.pizza.repository.OrdersRepository;
import com.cg.pizza.service.CartService;
import com.cg.pizza.serviceimpl.OrderServiceImpl;

public class OrderServiceImplTest {

    @Mock
    private OrdersRepository ordersRepository;
    @Mock
    private OrderedPizzaRepository orderedPizzaRepository;
    @Mock
    private CustomerRepo customerRepository;
    @Mock
    private CartRepository cartRepository;
    @Mock
    private CartService cartService;

    @InjectMocks
    private OrderServiceImpl orderService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testAddOrder() {
        int customerId = 1;

        Customer customer = new Customer();
        when(customerRepository.findById(customerId)).thenReturn(Optional.of(customer));

        Cart cart = new Cart();
        cart.setCustomer(customer);
        Pizza pizza = new Pizza();
        pizza.setPizzaName("Margherita");
        PizzaToppings pizzaToppings = new PizzaToppings();
        pizzaToppings.setPizza(pizza);
        pizzaToppings.setPizzaQuantity(2);
        cart.setPizzaToppings(List.of(pizzaToppings));
        when(cartRepository.findByCustomer(customer)).thenReturn(cart);

        double totalOrderPrice = 100.0;
        when(cartService.getTotalOrderPrice(customer)).thenReturn(totalOrderPrice);

        Orders order = new Orders();
        order.setCustomer(customer);
        order.setOrderDate(LocalDate.now());
        order.setStatus("Confirmed");
        order.setBill(totalOrderPrice);

        when(ordersRepository.save(any(Orders.class))).thenReturn(order);

        Orders result = orderService.addOrder(customerId);

        assertNotNull(result);
        assertEquals("Confirmed", result.getStatus());
        assertEquals(totalOrderPrice, result.getBill());
        verify(ordersRepository).save(any(Orders.class));
        verify(orderedPizzaRepository).save(any(OrderedPizza.class));
        verify(cartRepository).delete(cart);
    }

    @Test
    void testFindAll() {
        List<Orders> orders = List.of(new Orders(), new Orders());
        when(ordersRepository.findAll()).thenReturn(orders);

        List<Orders> result = orderService.findAll();

        assertEquals(2, result.size());
        verify(ordersRepository).findAll();
    }

    @Test
    void testGetOrdersByCustomerId() {
        int customerId = 1;

        Customer customer = new Customer();
        when(customerRepository.findById(customerId)).thenReturn(Optional.of(customer));

        List<Orders> orders = List.of(new Orders(), new Orders());
        when(ordersRepository.findByCustomer(customer)).thenReturn(orders);

        List<Orders> result = orderService.getOrdersByCustomerId(customerId);

        assertEquals(2, result.size());
        verify(ordersRepository).findByCustomer(customer);
    }

    @Test
    void testGetOrdersByCustomerNumber() {
        String mobileNumber = "1234567890";

        Customer customer = new Customer();
        when(customerRepository.findByMobileNumber(mobileNumber)).thenReturn(customer);

        List<Orders> orders = List.of(new Orders(), new Orders());
        when(ordersRepository.findByCustomer(customer)).thenReturn(orders);

        List<Orders> result = orderService.getOrdersByCustomerNumber(mobileNumber);

        assertEquals(2, result.size());
        verify(ordersRepository).findByCustomer(customer);
    }

    @Test
    void testGetOrdersByCustomerNumber_CustomerNotFound() {
        String mobileNumber = "1234567890";

        when(customerRepository.findByMobileNumber(mobileNumber)).thenReturn(null);

        ApplicationException exception = assertThrows(ApplicationException.class, () -> {
            orderService.getOrdersByCustomerNumber(mobileNumber);
        });

        assertEquals("Customer not found", exception.getMessage());
    }

    @Test
    void testGetOrdersByCustomerNumber_NoOrdersFound() {
        String mobileNumber = "1234567890";

        Customer customer = new Customer();
        when(customerRepository.findByMobileNumber(mobileNumber)).thenReturn(customer);

        when(ordersRepository.findByCustomer(customer)).thenReturn(List.of());

        ApplicationException exception = assertThrows(ApplicationException.class, () -> {
            orderService.getOrdersByCustomerNumber(mobileNumber);
        });

        assertEquals("No Orders Found", exception.getMessage());
    }

    @Test
    void testCancelOrder() {
        int orderId = 1;

        Orders order = new Orders();
        when(ordersRepository.findById(orderId)).thenReturn(Optional.of(order));

        Orders result = orderService.cancelOrder(orderId);

        assertEquals("Cancelled", result.getStatus());
        verify(ordersRepository).save(order);
    }

//    @Test
//    void testUpdateOrderStatus() {
//        int orderId = 1;
//
//        Orders order = new Orders();
//        when(ordersRepository.findById(orderId)).thenReturn(Optional.of(order));
//
//        Orders result = orderService.updateOrderStatus(orderId);
//
//        assertEquals("Delivered", result.getStatus());
//        verify(ordersRepository).save(order);
//    }
    
    
}

