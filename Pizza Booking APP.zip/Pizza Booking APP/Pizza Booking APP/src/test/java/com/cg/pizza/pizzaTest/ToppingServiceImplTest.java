package com.cg.pizza.pizzaTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import java.util.Optional;
import java.util.List;
import java.util.ArrayList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import com.cg.pizza.dto.ToppingsDTO;
import com.cg.pizza.entity.Toppings;
import com.cg.pizza.repository.ToppingsRepository;
import com.cg.pizza.serviceimpl.ToppingsServiceImpl;


public class ToppingServiceImplTest {

    @Mock
    private ToppingsRepository toppingsRepository;

    @InjectMocks
    private ToppingsServiceImpl toppingsServiceImpl;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testAddToppings() {
        ToppingsDTO toppingsDTO = new ToppingsDTO();
        toppingsDTO.setToppingName("Cheese");
        toppingsDTO.setToppingPrice(2.5);

        Toppings toppings = new Toppings();
        toppings.setToppingName("Cheese");
        toppings.setToppingPrice(2.5);

        when(toppingsRepository.save(any(Toppings.class))).thenReturn(toppings);

        ToppingsDTO result = toppingsServiceImpl.addToppings(toppingsDTO);

        assertEquals("Cheese", result.getToppingName());
        assertEquals(2.5, result.getToppingPrice());
    }

    @Test
    public void testUpdateToppings() {
        ToppingsDTO toppingsDTO = new ToppingsDTO();
        toppingsDTO.setToppingName("Pepperoni");
        toppingsDTO.setToppingPrice(3.0);

        Toppings toppings = new Toppings();
        toppings.setToppingId(1);
        toppings.setToppingName("Cheese");
        toppings.setToppingPrice(2.5);

        when(toppingsRepository.findById(1)).thenReturn(Optional.of(toppings));
        when(toppingsRepository.save(any(Toppings.class))).thenReturn(toppings);

        String result = toppingsServiceImpl.updateToppings(1, toppingsDTO);

        assertEquals("Updated Successfully", result);
        assertEquals("Pepperoni", toppings.getToppingName());
        assertEquals(3.0, toppings.getToppingPrice());
    }

    @Test
    public void testUpdateToppings_NotFound() {
        ToppingsDTO toppingsDTO = new ToppingsDTO();
        toppingsDTO.setToppingName("Pepperoni");
        toppingsDTO.setToppingPrice(3.0);

        when(toppingsRepository.findById(1)).thenReturn(Optional.empty());

        String result = toppingsServiceImpl.updateToppings(1, toppingsDTO);

        assertEquals("Toppings not updated", result);
    }

    @Test
    public void testRemoveToppings() {
        doNothing().when(toppingsRepository).deleteById(1);

        String result = toppingsServiceImpl.removeToppings(1);

        assertEquals("Deleted Successfully", result);
    }

    @Test
    public void testSearchToppingsById() {
        Toppings toppings = new Toppings();
        toppings.setToppingId(1);
        toppings.setToppingName("Cheese");
        toppings.setToppingPrice(2.5);

        when(toppingsRepository.findById(1)).thenReturn(Optional.of(toppings));

        ToppingsDTO result = toppingsServiceImpl.searchToppingsById(1);

        assertEquals(1, result.getToppingId());
        assertEquals("Cheese", result.getToppingName());
        assertEquals(2.5, result.getToppingPrice());
    }

    @Test
    public void testGetAllToppings() {
        Toppings topping1 = new Toppings();
        topping1.setToppingId(1);
        topping1.setToppingName("Cheese");
        topping1.setToppingPrice(2.5);

        Toppings topping2 = new Toppings();
        topping2.setToppingId(2);
        topping2.setToppingName("Pepperoni");
        topping2.setToppingPrice(3.0);

        List<Toppings> toppingsList = new ArrayList<>();
        toppingsList.add(topping1);
        toppingsList.add(topping2);

        when(toppingsRepository.findAll()).thenReturn(toppingsList);

        List<Toppings> result = toppingsServiceImpl.getAllToppings();

        assertEquals(2, result.size());
        assertEquals("Cheese", result.get(0).getToppingName());
        assertEquals("Pepperoni", result.get(1).getToppingName());
    }
}
