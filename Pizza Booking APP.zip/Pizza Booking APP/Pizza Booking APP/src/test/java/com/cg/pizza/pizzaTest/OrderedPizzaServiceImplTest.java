package com.cg.pizza.pizzaTest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.pizza.entity.OrderedPizza;
import com.cg.pizza.entity.Orders;
import com.cg.pizza.exceptions.ApplicationException;
import com.cg.pizza.repository.OrderedPizzaRepository;
import com.cg.pizza.repository.OrdersRepository;
import com.cg.pizza.serviceimpl.OrderServiceImpl;
import com.cg.pizza.serviceimpl.OrderedPizzaServiceImpl;

@ExtendWith(MockitoExtension.class)
public class OrderedPizzaServiceImplTest {

    @Mock
    private OrdersRepository ordersRepository;

    @Mock
    private OrderedPizzaRepository orderedPizzaRepository;

    @InjectMocks
    private OrderedPizzaServiceImpl orderService;

    @Test
    public void testGetPizzaByOrderId() {
        // Sample data
        Orders order = new Orders();
        order.setOrderId(1);

        OrderedPizza pizza1 = new OrderedPizza();
        pizza1.setBillId(1);
        pizza1.setOrder(order);
        
        OrderedPizza pizza2 = new OrderedPizza();
        pizza2.setBillId(2);
        pizza2.setOrder(order);
        
        List<OrderedPizza> pizzas = Arrays.asList(pizza1, pizza2);

        // Mocking behavior
        when(ordersRepository.findById(1)).thenReturn(Optional.of(order));
        when(orderedPizzaRepository.findByOrder(order)).thenReturn(pizzas);

        // Calling the service method
        List<OrderedPizza> result = orderService.getPizzaByOrderId(1);

        // Assertions
        assertEquals(2, result.size());
        assertEquals(1, result.get(0).getBillId());
        assertEquals(2, result.get(1).getBillId());
        assertEquals(order, result.get(0).getOrder());
        assertEquals(order, result.get(1).getOrder());
    }

    @Test
    public void testGetPizzaByInvalidOrderId() {
        // Mocking behavior for invalid order ID
        when(ordersRepository.findById(999)).thenReturn(Optional.empty());

        // Calling the service method with invalid order ID
        try {
            orderService.getPizzaByOrderId(999);
            fail("Expected an ApplicationException to be thrown");
        } catch (ApplicationException e) {
            assertEquals("Invalid OrderId", e.getMessage());
        }
    }
}
