package com.cg.pizza.pizzaTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.pizza.dto.CustomerDTO;
import com.cg.pizza.entity.Address;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.exceptions.ApplicationException;
import com.cg.pizza.repository.CustomerRepo;
import com.cg.pizza.serviceimpl.CustomerServiceImpl;


public class CustomerServiceImplTest {

	@Mock
	private CustomerRepo customerRepository;

	@InjectMocks
	private CustomerServiceImpl customerServiceImpl;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testUpdateCustomerDetails() {
		CustomerDTO customerDTO = new CustomerDTO();
		customerDTO.setCustomerId(1);
		customerDTO.setCustomerFirstName("Vaishali");
		customerDTO.setCustomerLastName("Ramesh");
		customerDTO.setEmail("vaishali@gmail.com");
		customerDTO.setMobileNumber("1234567890");
		Address address = new Address();
		address.setHouseNo(800);
		address.setStreetName("Main Street");
		address.setCity("Bangalore");
		address.setState("Karnataka");
		Customer customer = new Customer();
		customer.setCustomerId(1);
		customer.setCustomerFirstName("Vaishali");
		customer.setCustomerLastName("Ramesh");
		customer.setEmail("vaishali@gmail.com");
		customer.setMobileNumber("1234567890");
		Address address1 = new Address();
		address1.setHouseNo(800);
		address1.setStreetName("Main Street");
		address1.setCity("Bangalore");
		address1.setState("Karnataka");

		when(customerRepository.findById(1)).thenReturn(java.util.Optional.of(customer));

		Customer updatedCustomer = customerServiceImpl.updateCustomerDetails(customerDTO);

		verify(customerRepository, times(1)).save(any(Customer.class));

		assertEquals(customerDTO.getCustomerFirstName(), updatedCustomer.getCustomerFirstName());
		assertEquals(customerDTO.getCustomerLastName(), updatedCustomer.getCustomerLastName());
		assertEquals(customerDTO.getEmail(), updatedCustomer.getEmail());
		assertEquals(customerDTO.getMobileNumber(), updatedCustomer.getMobileNumber());

	}

	@Test
	public void testGetByEmail_CustomerFound() {
		String email = "amulya@gmail.com";
		Customer mockCustomer = new Customer();
		mockCustomer.setEmail(email);
		when(customerRepository.findByEmail(email)).thenReturn(mockCustomer);

		Customer result = customerServiceImpl.getByEmail(email);

		verify(customerRepository).findByEmail(email);

		assertEquals(mockCustomer, result);
	}

	@Test
	public void testGetByEmail_CustomerNotFound() {
		String email = "nonexistent@example.com";
		when(customerRepository.findByEmail(email)).thenReturn(null);

		assertThrows(ApplicationException.class, () -> {
			customerServiceImpl.getByEmail(email);
		});
	}

	@Test
	public void testGetByPhoneNo_CustomerFound() {
		String mobileNumber = "1234567890";
		Customer mockCustomer = new Customer();
		mockCustomer.setMobileNumber(mobileNumber);
		when(customerRepository.findByMobileNumber(mobileNumber)).thenReturn(mockCustomer);

		Customer result = customerServiceImpl.getByPhoneNo(mobileNumber);

		verify(customerRepository).findByMobileNumber(mobileNumber);

		assertNotNull(result);
		assertEquals(mockCustomer, result);
	}

	@Test
	public void testGetByPhoneNo_CustomerNotFound() {
		String mobileNumber = "1234567890";
		when(customerRepository.findByMobileNumber(mobileNumber)).thenReturn(null);

		assertThrows(ApplicationException.class, () -> {
			customerServiceImpl.getByPhoneNo(mobileNumber);
		});
	}

	@Test
	public void testAddCustomerDetails() {

		CustomerDTO customerDTO = new CustomerDTO();
		customerDTO.setCustomerFirstName("Vaishali");
		customerDTO.setCustomerLastName("Ramesh");
		customerDTO.setEmail("vaishali@gmail.com");
		customerDTO.setMobileNumber("1234567890");
		Address address = new Address();
		address.setHouseNo(800);
		address.setStreetName("Main Street");
		address.setCity("Bangalore");
		address.setState("Karnataka");

		Customer savedCustomer = new Customer();
		savedCustomer.setCustomerId(1);
		when(customerRepository.save(savedCustomer)).thenReturn(savedCustomer);

		Customer result = customerServiceImpl.addCustomerDetails( customerDTO);

		assertEquals(savedCustomer.getUsername(), result.getUsername());
	}

	@Test
	public void testGetAll() {
		List<Customer> customers = new ArrayList<>();
		customers.add(new Customer());
		customers.add(new Customer());
		when(customerRepository.findAll()).thenReturn(customers);

		List<Customer> result = customerServiceImpl.getAll();

		verify(customerRepository).findAll();

		assertEquals(customers, result);
	}

	@Test
	public void testGetById_CustomerFound() {
		int id = 1;
		Customer mockCustomer = new Customer();
		when(customerRepository.findById(id)).thenReturn(Optional.of(mockCustomer));

		Customer result = customerServiceImpl.getByCustomerId(id);

		verify(customerRepository).findById(id);

		assertNotNull(result);
		assertEquals(mockCustomer, result);
	}

	@Test
	public void testGetById_CustomerNotFound() {
		int id = 1;
		when(customerRepository.findById(id)).thenReturn(Optional.empty());

		assertThrows(ApplicationException.class, () -> customerServiceImpl.getByCustomerId(id));
	}

}