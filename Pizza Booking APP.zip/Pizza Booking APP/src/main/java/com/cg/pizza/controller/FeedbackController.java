package com.cg.pizza.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.pizza.dto.FeedbackDTO;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.FeedBack;
import com.cg.pizza.service.FeedbackService;
import com.cg.pizza.serviceimpl.CustomerServiceImpl;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/feedback")
@SecurityRequirement(name = "Bearer Authentication")
public class FeedbackController {
	@Autowired
	private FeedbackService feedbackService;
	@Autowired
	private CustomerServiceImpl custservice;
	//@RequestBody is used to extract the HTTP request body data, often in JSON or XML format, and deserialize it into a Java object.
	@PostMapping
	public FeedBack addFeedback(Principal p, @Valid @RequestBody FeedbackDTO fbDto) {
		System.out.println(p.getName());
		Customer c = custservice.findByUsername(p.getName());
		fbDto.setCustomerId(c.getCustomerId());
		return feedbackService.addFeedback(fbDto);
	}

	@GetMapping(value = "/{feedbackId}")
	public FeedBack getFeedback(@PathVariable("feedbackId") int feedbackId) {
		return feedbackService.getFeedback(feedbackId);
	}

	@GetMapping
	public List<FeedBack> getAllFeedback() {
		return feedbackService.getAllFeedback();
	}

	@DeleteMapping(value = "/{feedbackId}")
	public void deletePatient(@PathVariable("feedbackId") int feedbackId) {
		// Delegate the delete operation to the MovieService
		// System.out.println("in delete");
		feedbackService.deleteFeedback(feedbackId);
	}

	@PutMapping
	public FeedBack updateFeedback(@Valid @RequestBody FeedbackDTO feedDto) {
		return feedbackService.updateFeedback(feedDto);
	}

	@GetMapping(value = "/searchCustomer")
	public List<FeedBack> searchByCustomerId(Principal p) {
		Customer c = custservice.findByUsername(p.getName());
		return feedbackService.searchByCustomerIdService(c.getCustomerId());
	}

	@GetMapping(value = "/searchPizza/{pizzaId}")
	public List<FeedBack> searchByPizzaId(@PathVariable("pizzaId") int pizzaId) {
		return feedbackService.searchByPizzaIdService(pizzaId);
	}
}