package com.cg.pizza.controller;
import java.security.Principal;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.pizza.dto.CartDTO;
import com.cg.pizza.dto.PizzaToppingsDTO;
import com.cg.pizza.entity.Cart;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.PizzaToppings;
import com.cg.pizza.repository.CustomerRepo;
import com.cg.pizza.service.CartService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
 
@RestController
@RequestMapping("/cart")
@SecurityRequirement(name="Bearer Authentication")
public class CartController {
	@Autowired
	private CartService cartService;
	@Autowired
	private CustomerRepo customerRepository;
	@PostMapping
	public Cart addPizzatoCart(Principal p,@Valid @RequestBody CartDTO cartDto) {
		Customer c = customerRepository.findByUsername(p.getName());
		cartDto.setCustomerId(c.getCustomerId());
		return cartService.addPizzatoCart(cartDto);
	}
	@PutMapping
	public PizzaToppings updatePizzaQuantity( @Valid @RequestBody PizzaToppings ptDto){
		return cartService.updatePizzaQuantity(ptDto);
	}
	@DeleteMapping
	public void deleteCartItemsByCustomerId(Principal p){
		Customer c = customerRepository.findByUsername(p.getName());
		 cartService.deleteCartItemsByCustomerId(c.getCustomerId());
	}
	@GetMapping("/pizza")
	public Cart getCartItemsByCustomerId(Principal p){
		Customer customer = customerRepository.findByUsername(p.getName());
		return cartService.getCartItemsByCustomerId(customer.getCustomerId());
 
	}
	@DeleteMapping("/deletePizza/{id}")
	public void deletePizzafromCart(Principal p,@PathVariable int id) {
		cartService.deletePizzafromCart(id);
	}
		
	@PostMapping("/{toppingId}")
	public PizzaToppings addPizzaToppings(@RequestBody PizzaToppingsDTO ptDTO,@PathVariable("toppingId") int toppingId) {
		return cartService.addPizzaToppings(ptDTO, toppingId);
	}
	
	@DeleteMapping("/pizzatoppings/{ptId}")
    public void deletePizzaToppings(@PathVariable int ptId) {
            cartService.deletePizzaToppings(ptId);
	}
	
	@GetMapping("/orderprice")
	public double getTotalOrderPrice(Principal p) {
	    Customer c = customerRepository.findByUsername(p.getName());
	    return cartService.getTotalOrderPrice(c);
	}
	@GetMapping("/pizzaToppings")
	public List<PizzaToppings> getAllPizzaToppings(){
		return cartService.getAllPizzaToppings();
	}
}