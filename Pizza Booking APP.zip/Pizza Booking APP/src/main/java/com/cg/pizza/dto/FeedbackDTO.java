package com.cg.pizza.dto;

public class FeedbackDTO {
	private int feedbackId;
	private int customerId;
	private int pizzaId;
	private int rating;
	private String feedback;

	public FeedbackDTO() {
		super();
	}

	public FeedbackDTO(int feedbackId, int customerId, int pizzaId, int rating, String feedback) {
		super();
		this.feedbackId = feedbackId;
		this.customerId = customerId;
		this.pizzaId = pizzaId;
		this.rating = rating;
		this.feedback = feedback;
	}

	public int getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getPizzaId() {
		return pizzaId;
	}

	public void setPizzaId(int pizzaId) {
		this.pizzaId = pizzaId;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
}