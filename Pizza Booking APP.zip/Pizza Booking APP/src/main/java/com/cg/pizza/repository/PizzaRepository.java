package com.cg.pizza.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.pizza.entity.Category;
import com.cg.pizza.entity.Pizza;

@Repository
public interface PizzaRepository extends JpaRepository<Pizza, Integer> {
	List<Pizza> findByCategory(Category category);

	List<Pizza> findAllByPizzaSize(String pizzaSize);

	Pizza findByPizzaName(String pizzaName);

	Pizza findByPizzaId(int pizzaId);
}
