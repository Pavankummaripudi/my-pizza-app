package com.cg.pizza.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cg.pizza.entity.OrderedPizza;
import com.cg.pizza.entity.Orders;

@Repository
public interface OrderedPizzaRepository extends JpaRepository<OrderedPizza, Integer> {
	public List<OrderedPizza> findByOrder(Orders order);
}
