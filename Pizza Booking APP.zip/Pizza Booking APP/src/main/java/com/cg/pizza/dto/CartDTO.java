package com.cg.pizza.dto;

public class CartDTO {
	private int cartId;
	private int customerId;
	private int pizzaToppingId;
	private int toppingQuantity = 1;

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public void setToppingQuantity(int toppingQuantity) {
		this.toppingQuantity = toppingQuantity;
	}

	public int getToppingQuantity() {
		return toppingQuantity;
	}

	public int getPizzaToppingId() {
		return pizzaToppingId;
	}

	public void setPizzaToppingId(int pizzaToppingId) {
		this.pizzaToppingId = pizzaToppingId;
	}

	public CartDTO(int cartId, int customerId, int pizzaToppingId, int toppingQuantity) {
		super();
		this.cartId = cartId;
		this.customerId = customerId;
		this.pizzaToppingId = pizzaToppingId;
		this.toppingQuantity = toppingQuantity;
	}

	public CartDTO() {
	}
}