package com.cg.pizza.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.pizza.entity.Category;
import com.cg.pizza.service.CategoryService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/category")
@SecurityRequirement(name = "Bearer Authentication")
public class CategoryController {
	@Autowired
	private CategoryService categoryService;

	@GetMapping
	public List<Category> getAllCategories() {
		return categoryService.allCategory();
	}
	//Adds a new category.
	@PostMapping
	public Category addCategory(@Valid @RequestBody Category category) {
		return categoryService.addCategory(category);
	}

	@GetMapping("/{categoryId}")
	public Category searchById(@PathVariable("categoryId") int id) {
		return categoryService.searchCategoryById(id);
	}

	@PutMapping("/{categoryId}")
	public Category updateCategory(@Valid @RequestBody Category updatedCategory,
			@PathVariable("categoryId") int categoryId) {
		return categoryService.updateCategory(updatedCategory, categoryId);
	}

	@DeleteMapping("/{categoryId}")
	public void deleteCategory(@PathVariable("categoryId") int categoryId) {
		categoryService.deleteCategory(categoryId);
	}

	@GetMapping("/name/{categoryName}")
	public Category searchByName(@PathVariable("categoryName") String categoryName) {
		return categoryService.searchCategoryByName(categoryName.toLowerCase());
	}
}