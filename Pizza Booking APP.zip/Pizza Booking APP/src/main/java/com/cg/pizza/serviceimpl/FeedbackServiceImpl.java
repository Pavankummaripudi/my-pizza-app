package com.cg.pizza.serviceimpl;

import java.util.List;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.pizza.dto.FeedbackDTO;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.FeedBack;
import com.cg.pizza.entity.Pizza;
import com.cg.pizza.repository.CustomerRepo;
import com.cg.pizza.repository.FeedbackRepository;
import com.cg.pizza.repository.PizzaRepository;
import com.cg.pizza.service.FeedbackService;

@Component

public class FeedbackServiceImpl implements FeedbackService {

	@Autowired

	FeedbackRepository fDao;

	@Autowired

	CustomerRepo customerRepo;

	@Autowired

	PizzaRepository pizzaRepo;

	@Override

	public FeedBack addFeedback(FeedbackDTO fdb) {

		FeedBack fb = new FeedBack();

		Pizza doc = pizzaRepo.findById(fdb.getPizzaId())
				.orElseThrow(() -> new RuntimeException("Cannot find Pizza Id!!"));

		Customer pat = customerRepo.findById(fdb.getCustomerId())
				.orElseThrow(() -> new RuntimeException("Cannot find Customer Id!!"));

		fb.setPizza(doc);

		fb.setCustomer(pat);

		BeanUtils.copyProperties(fdb, fb);

		return fDao.save(fb);

	}

	@Override

	public FeedBack getFeedback(int feedbackId) {

		FeedBack fobj = fDao.findById(feedbackId).orElseThrow(() -> new RuntimeException("Feedback not present!!"));

		return fobj;

	}

	@Override

	public List<FeedBack> getAllFeedback() {

		// TODO Auto-generated method stub

		return fDao.findAll();

	}

	@Override

	public FeedBack updateFeedback(FeedbackDTO feedbackDTO) {

		FeedBack c = fDao.findById(feedbackDTO.getCustomerId()).get();

		BeanUtils.copyProperties(feedbackDTO, c);

		fDao.save(c);

		return c;

	}

	/*
	 * @Override
	 * 
	 * public void deleteFeedback(FeedbackDTO fdto)
	 * 
	 * {
	 * 
	 * fDao.deleteById(fdto.getFeedbackId());
	 * 
	 * }
	 */

	@Override

	public void deleteFeedback(int feedbackId)

	{

		fDao.deleteById(feedbackId);

	}

	@Override

	public List<FeedBack> searchByCustomerIdService(int customerId)

	{

		/*
		 * int patientId=fdto.getPatientId();
		 * 
		 * FeedBack f=fDao.findById().orElseThrow(()->new
		 * RuntimeException("Cannot find Patient Id!!"));
		 * 
		 * return f;
		 */

		return fDao.searchByCustomerId(customerId);

	}

	@Override

	public List<FeedBack> searchByPizzaIdService(int pizzaId)

	{

		/*
		 * int patientId=fdto.getPatientId();
		 * 
		 * FeedBack f=fDao.findById().orElseThrow(()->new
		 * RuntimeException("Cannot find Patient Id!!"));
		 * 
		 * return f;
		 */

		return fDao.searchByPizzaId(pizzaId);

	}

}
