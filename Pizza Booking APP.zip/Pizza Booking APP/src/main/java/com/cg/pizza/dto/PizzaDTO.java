package com.cg.pizza.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class PizzaDTO {

	private int pizzaId;
	@Min(value = 1, message = "Category ID must be a positive number")
	private int categoryId;
	@NotBlank(message = "Pizza name is mandatory")
	@Size(min = 3, max = 50, message = "Pizza name must be between 3 and 50 characters")
	private String pizzaName;
	@Min(value = 0, message = "Pizza price must be a positive number")
	private double pizzaPrice;
	@NotBlank(message = "Pizza size is mandatory")
	@Size(min = 1, max = 10, message = "Pizza size must be between 1 and 10 characters")
	private String pizzaSize;

	private String imageUrl;

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public PizzaDTO() {

	}

	public int getPizzaId() {
		return pizzaId;
	}

	public void setPizzaId(int pizzaId) {
		this.pizzaId = pizzaId;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public String getPizzaSize() {
		return pizzaSize;
	}

	public void setPizzaSize(String pizzaSize) {
		this.pizzaSize = pizzaSize;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getPizzaName() {
		return pizzaName;
	}

	public void setPizzaName(String pizzaName) {
		this.pizzaName = pizzaName;
	}

	public double getPizzaPrice() {
		return pizzaPrice;
	}

	public void setPizzaPrice(double pizzaPrice) {
		this.pizzaPrice = pizzaPrice;
	}

	@Override
	public String toString() {
		return "FoodItemsDTO [id=" + pizzaId + ", categoryId=" + categoryId + ", itemName=" + pizzaName + ", itemPrice="
				+ pizzaPrice + ", size=" + pizzaSize + "]";
	}

	public PizzaDTO(int pizzaId, int categoryId, String pizzaName, double pizzaPrice, String pizzaSize) {
		super();
		this.pizzaId = pizzaId;
		this.categoryId = categoryId;
		this.pizzaName = pizzaName;
		this.pizzaPrice = pizzaPrice;
		this.pizzaSize = pizzaSize;
	}

	public PizzaDTO(String pizzaName) {
		this.pizzaName = pizzaName;
	}

}
