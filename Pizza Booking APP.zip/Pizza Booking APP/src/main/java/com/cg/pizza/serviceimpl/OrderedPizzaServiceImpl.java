package com.cg.pizza.serviceimpl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.pizza.entity.OrderedPizza;
import com.cg.pizza.entity.Orders;
import com.cg.pizza.exceptions.ApplicationException;
import com.cg.pizza.repository.OrderedPizzaRepository;
import com.cg.pizza.repository.OrdersRepository;
import com.cg.pizza.service.OrderedPizzaService;

import jakarta.transaction.Transactional;

@Service // This annotation marks the class as a Spring service, making it a candidate for Spring's component scanning to detect and register as a bean in the application context.
@Transactional // This annotation ensures that all the methods within this class are executed within a transactional context. It helps in managing transactions and rolling back in case of an exception.
public class OrderedPizzaServiceImpl implements OrderedPizzaService {

	@Autowired//(pass a bean to the class so spring can create objects )
	private OrderedPizzaRepository orderedPizzaRepository;
	@Autowired // This annotation is used for automatic dependency injection. It tells Spring to inject the required beans (repositories and services) into this class.
	private OrdersRepository ordersRepository;

	@Override
	public List<OrderedPizza> getPizzaByOrderId(int orderId) {//we get pizza by orderId
		Orders order = ordersRepository.findById(orderId)// Retrieves the order by its ID. If the order is not found, an ApplicationException is thrown.
				.orElseThrow(() -> new ApplicationException("Invalid OrderId"));
		return orderedPizzaRepository.findByOrder(order); // Finds and returns the list of OrderedPizza entities associated with the retrieved order.
	}
}
