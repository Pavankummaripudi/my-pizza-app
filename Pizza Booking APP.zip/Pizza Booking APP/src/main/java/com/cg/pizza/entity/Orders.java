package com.cg.pizza.entity;

import java.time.LocalDate;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity 
@SequenceGenerator(name = "seq_orders", sequenceName = "myseqorders", allocationSize = 1, initialValue = 300)
public class Orders {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_orders") 
	private int orderId;
	@NotNull(message = "Order date must not be null")
	private LocalDate orderDate;
	@Min(value = 1, message = "Bill must be at least 1")
	private double bill;
	@Column(length = 20)
	@Size(max = 20, message = "Status must not exceed 20 characters")
	@NotNull(message = "Status must not be null")
	private String status;
	@ManyToOne
	@JoinColumn(name = "customerId")
	@NotNull
	private Customer customer;

	public Orders() {

	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public double getBill() {
		return bill;
	}

	public void setBill(double bill) {
		this.bill = bill;
	}

	public Orders(int orderId, LocalDate orderDate, double bill, String status, Customer customer) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.bill = bill;
		this.status = status;
		this.customer = customer;
	}
}
