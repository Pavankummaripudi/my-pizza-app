package com.cg.pizza.exceptions;

import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException;

@RestControllerAdvice//Global exception handler for Spring MVC controllers or REST endpoints.
public class GlobalExceptionHandler {
    // Handles exceptions of type ApplicationException and its subclasses.
    // Creates an ApiError object with the exception message and returns
    // a ResponseEntity with HTTP status code 404 (Not Found).
    
	@ExceptionHandler(ApplicationException.class)
	public ResponseEntity<ApiError> handle(ApplicationException e) {
		ApiError error = new ApiError();
		error.setMsg(e.getMessage());
		return new ResponseEntity<ApiError>(error, HttpStatusCode.valueOf(404));
	}
     //Handles unauthorized access exceptions (HttpClientErrorException.Unauthorized).
     //Returns a string message indicating unauthorized access along with the exception message.
     
	@ExceptionHandler(HttpClientErrorException.Unauthorized.class)
	@ResponseBody
	public String handleUnauthorizedException(HttpClientErrorException.Unauthorized ex) {
		// Customize the response message or redirect the user to a login page
		return "Unauthorized access: " + ex.getMessage();
	}
}
