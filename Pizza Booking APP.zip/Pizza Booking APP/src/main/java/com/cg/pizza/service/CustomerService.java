package com.cg.pizza.service;

import java.util.List;

import com.cg.pizza.dto.CustomerDTO;
import com.cg.pizza.entity.Customer;

public interface CustomerService {
	Customer updateCustomerDetails(CustomerDTO customerdto);

	Customer getByEmail(String email);

	Customer getByPhoneNo(String mobileNumber);

	Customer addCustomerDetails(CustomerDTO customerdto);

	List<Customer> getAll();

	Customer getByCustomerId(int customerId);

	Customer findByUsername(String username);
}
