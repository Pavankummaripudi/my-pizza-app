package com.cg.pizza.service;

import java.util.List;
import com.cg.pizza.entity.Orders;

public interface OrdersService {

	public Orders addOrder(int customerId);

	public Orders cancelOrder(int orderId);

	public List<Orders> findAll();

	public List<Orders> getOrdersByCustomerId(int customerId);

	public Orders updateOrderStatus(int orderId);

}
