package com.cg.pizza.serviceimpl;

import java.time.LocalDate;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.pizza.entity.Cart;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.OrderedPizza;
import com.cg.pizza.entity.Orders;
import com.cg.pizza.entity.Pizza;
import com.cg.pizza.entity.PizzaToppings;
import com.cg.pizza.exceptions.ApplicationException;
import com.cg.pizza.repository.CartRepository;
import com.cg.pizza.repository.CustomerRepo;
import com.cg.pizza.repository.OrderedPizzaRepository;
import com.cg.pizza.repository.OrdersRepository;
import com.cg.pizza.service.CartService;
import com.cg.pizza.service.OrdersService;

@Service
@Transactional 
public class OrderServiceImpl implements OrdersService {
	@Autowired
	private OrdersRepository ordersRepository;
	@Autowired
	private OrderedPizzaRepository orderedPizzaRepository;
	@Autowired
	private CustomerRepo customerRepository;
	@Autowired
	private CartRepository cartRepository;
	 @Autowired 
	private CartService cartService;

	// Method to add a new order for a customer
	@Override
	public Orders addOrder(int customerId) {
		Customer customer = customerRepository.findById(customerId)
				.orElseThrow(() -> new ApplicationException("Invalid Customer"));
		Cart cart = cartRepository.findByCustomer(customer);//->by using customer obj cart details will be fetched
		Orders order = new Orders();
		order.setCustomer(customer);
		order.setOrderDate(LocalDate.now());
		order.setStatus("Confirmed");
		order.setBill(cartService.getTotalOrderPrice(customer));
		ordersRepository.save(order);
		List<PizzaToppings> pizzaToppings = cart.getPizzaToppings();//order->ordered(history)
		for (PizzaToppings topping : pizzaToppings) {
			OrderedPizza orderedPizza = new OrderedPizza();
			Pizza pizza = topping.getPizza();
			orderedPizza.setPizzaName(pizza.getPizzaName());
			orderedPizza.setQuantity(topping.getPizzaQuantity());
			orderedPizza.setOrder(order);
			orderedPizzaRepository.save(orderedPizza);
		}
		// Clear cart after ordering
		cartRepository.delete(cart);
		return order;
	}

	// Method to retrieve all orders
	@Override
	public List<Orders> findAll() {
		return ordersRepository.findAll();
	}

	// Method to retrieve orders by customer ID
	@Override
	public List<Orders> getOrdersByCustomerId(int customerId) {
		Customer customer = customerRepository.findById(customerId)
				.orElseThrow(() -> new ApplicationException("Invalid Customer"));
		return ordersRepository.findByCustomer(customer);
	}

	// Method to cancel an order
	@Override
	public Orders cancelOrder(int orderId) {
		Orders order = ordersRepository.findById(orderId)
				.orElseThrow(() -> new ApplicationException("Invalid OrderId"));
		order.setStatus("Cancelled");
		ordersRepository.save(order);
		return order;
	}

	// Method to update order status to delivered
	@Override
	public Orders updateOrderStatus(int orderId) {
		Orders order = ordersRepository.findById(orderId)
				.orElseThrow(() -> new ApplicationException("Invalid OrderId"));
		order.setStatus("Delivered");
		return ordersRepository.save(order);
	}
}
