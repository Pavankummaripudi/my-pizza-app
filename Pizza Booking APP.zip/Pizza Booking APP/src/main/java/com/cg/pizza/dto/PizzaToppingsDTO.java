package com.cg.pizza.dto;

import java.util.List;

import com.cg.pizza.entity.Toppings;

import jakarta.validation.constraints.Min;

public class PizzaToppingsDTO {
	private int pizzaToppingId;
	@Min(value = 1, message = "Pizza ID must be a positive number")
	private int pizzaId;
	private List<Toppings> top;
	@Min(value = 1, message = "Pizza quantity must be at least 1")
	private int pizzaQuantity;

	public int getPizzaId() {
		return pizzaId;
	}

	public void setPizzaId(int pizzaId) {
		this.pizzaId = pizzaId;
	}

	public List<Toppings> getTop() {
		return top;
	}

	public void setTop(List<Toppings> top) {
		this.top = top;
	}

	public int getPizzaToppingIdId() {
		return pizzaToppingId;
	}

	public void setPizzaToppingIdId(int pizzaToppingId) {
		this.pizzaToppingId = pizzaToppingId;
	}

	public int getPizzaQuantity() {
		return pizzaQuantity;
	}

	public void setPizzaQuantity(int pizzaQuantity) {
		this.pizzaQuantity = pizzaQuantity;
	}

}
