package com.cg.pizza.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
@Entity
public class Customer {
	@Id
	@GeneratedValue
    private int customerId;
//	@NotBlank(message = "Username is Mandatory")
	@Size(min = 3,max = 20,message = "Username must be between 3 and 20 characters")
    private String username;
	@NotBlank(message = "First name is mandatory")
	@Size(min = 3,max = 20,message = "Username must be between 3 and 20 characters")
    private String customerFirstName;
	@NotBlank(message = "last name is mandatory")
	@Size(min = 0,max = 50,message = "Last name must be between 0 and 50 characters")
	private String customerLastName;
	@NotBlank(message = "mobile number is mandatory")
	@Pattern(regexp = "\\d{10}",message = "Mobile number should be 10 digits only")
	private String mobileNumber;
	@NotNull(message = "Address is mandatory")
	private Address address;
	@NotBlank(message = "Email is mandatory")
	@Email(message = "Email should be valid")
	private String email;
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getCustomerFirstName() {
		return customerFirstName;
	}
	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}
	public String getCustomerLastName() {
		return customerLastName;
	}
	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Customer(int customerId, String username, String customerFirstName, String customerLastName,
			String mobileNumber, Address address, String email) {
		super();
		this.customerId = customerId;
		this.username = username;
		this.customerFirstName = customerFirstName;
		this.customerLastName = customerLastName;
		this.mobileNumber = mobileNumber;
		this.address = address;
		this.email = email;
	}
	
	 public Customer() {
		// TODO Auto-generated constructor stub
	}

}
