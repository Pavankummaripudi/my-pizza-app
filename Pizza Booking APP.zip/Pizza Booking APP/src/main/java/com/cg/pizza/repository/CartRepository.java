package com.cg.pizza.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.pizza.entity.Cart;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.PizzaToppings;

@Repository
public interface CartRepository  extends JpaRepository<Cart,Integer> {
	Cart findByCustomer(Customer cutomer);
    Cart findByCustomerAndPizzaToppings(Customer customer, PizzaToppings pt);
    Cart findByPizzaToppings(PizzaToppings pt);
    @Modifying
    @Query(value = "delete from cart_pizza_toppings where pizza_toppings_pt_id=:ptId",nativeQuery = true)
    void deleteByPizzaToppingsId(@Param("ptId") int ptId);//parameters
}