package com.cg.pizza.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.pizza.dto.ToppingsDTO;
import com.cg.pizza.entity.Toppings;
import com.cg.pizza.exceptions.ApplicationException;
import com.cg.pizza.repository.ToppingsRepository;
import com.cg.pizza.service.ToppingsService;

@Service
public class ToppingsServiceImpl implements ToppingsService {

	@Autowired
	private ToppingsRepository toppingsRepository;

	@Override
	public ToppingsDTO addToppings(ToppingsDTO toppingsDTO) {
		Toppings toppings = new Toppings();
		toppings.setToppingId(toppings.getToppingId());
		toppings.setToppingName(toppingsDTO.getToppingName());
		toppings.setToppingPrice(toppingsDTO.getToppingPrice());
		toppingsRepository.save(toppings);
		return toppingsDTO;
	}


	@Override
	public String updateToppings(int toppingsId, ToppingsDTO toppingsDTO) {
		try {
			Toppings toppings = toppingsRepository.findById(toppingsId)
					.orElseThrow(() -> new ApplicationException("No toppings found"));
			toppings.setToppingName(toppingsDTO.getToppingName());
			toppings.setToppingPrice(toppingsDTO.getToppingPrice());
			toppingsRepository.save(toppings);

		} catch (ApplicationException e) {
			System.out.println(e);
			return "Toppings not updated";
		}
		return "Updated Successfully";
	}

	@Override
	public String removeToppings(int toppingsId) {

		toppingsRepository.deleteById(toppingsId);
		return "Deleted Successfully";
	}

	@Override
	public ToppingsDTO searchToppingsById(int toppingsId) {
		Toppings toppings = toppingsRepository.findById(toppingsId).get();

		ToppingsDTO toppingsDTO = new ToppingsDTO();
		toppingsDTO.setToppingId(toppings.getToppingId());
		toppingsDTO.setToppingName(toppings.getToppingName());
		toppingsDTO.setToppingPrice(toppings.getToppingPrice());
		return toppingsDTO;

	}

	@Override
	public List<Toppings> getAllToppings() {
	return	toppingsRepository.findAll();
		
	}

}
