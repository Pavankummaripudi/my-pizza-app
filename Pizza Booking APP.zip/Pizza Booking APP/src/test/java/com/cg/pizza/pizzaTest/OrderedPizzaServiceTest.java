/**
 * 
 */
package com.cg.pizza.pizzaTest;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.pizza.entity.OrderedPizza;
import com.cg.pizza.service.OrderedPizzaService;

public class OrderedPizzaServiceTest {

    @Mock
    private OrderedPizzaService orderedPizzaService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetPizzaByOrderId() {
        int orderId = 1;
        List<OrderedPizza> orderedPizzaList = Arrays.asList(new OrderedPizza(), new OrderedPizza());
        when(orderedPizzaService.getPizzaByOrderId(orderId)).thenReturn(orderedPizzaList);

        List<OrderedPizza> result = orderedPizzaService.getPizzaByOrderId(orderId);

        assertNotNull(result);
        assertEquals(2, result.size());
        verify(orderedPizzaService, times(1)).getPizzaByOrderId(orderId);
    }
}
