package com.cg.pizza.pizzaTest;



import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.security.Principal;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.cg.pizza.controller.CartController;
import com.cg.pizza.dto.CartDTO;
import com.cg.pizza.dto.PizzaToppingsDTO;
import com.cg.pizza.entity.Cart;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.PizzaToppings;
import com.cg.pizza.service.CartService;
import com.cg.pizza.repository.CustomerRepo;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
public class CartControllerTest {

    @InjectMocks
    private CartController cartController;

    @Mock
    private CartService cartService;

    @Mock
    private CustomerRepo customerRepository;

    private MockMvc mockMvc;
    private ObjectMapper objectMapper;

    private Customer customer;
    private Cart cart;
    private PizzaToppings pizzaToppings;
    private Principal principal;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(cartController).build();
        objectMapper = new ObjectMapper();

        customer = new Customer();
        customer.setCustomerId(1);
        customer.setUsername("testuser");

        pizzaToppings = new PizzaToppings();
        pizzaToppings.setPtId(1);
        cart = new Cart();
        cart.setCustomer(customer);
        cart.setPizzaToppings(List.of(pizzaToppings));

        principal = mock(Principal.class);
        when(principal.getName()).thenReturn("testuser");
    }

    @Test
    void addPizzatoCart_Success() throws Exception {
        CartDTO cartDTO = new CartDTO();
        cartDTO.setPizzaToppingId(1);

        when(customerRepository.findByUsername("testuser")).thenReturn(customer);
        when(cartService.addPizzatoCart(any(CartDTO.class))).thenReturn(cart);

        mockMvc.perform(post("/cart")
                .principal(principal)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(cartDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.customer.customerId").value(1));
    }

    @Test
    void deleteCartItemsByCustomerId_Success() throws Exception {
        when(customerRepository.findByUsername("testuser")).thenReturn(customer);

        mockMvc.perform(delete("/cart")
                .principal(principal))
                .andExpect(status().isOk());

        verify(cartService, times(1)).deleteCartItemsByCustomerId(1);
    }

    @Test
    void getCartItemsByCustomerId_Success() throws Exception {
        when(customerRepository.findByUsername("testuser")).thenReturn(customer);
        when(cartService.getCartItemsByCustomerId(1)).thenReturn(cart);

        mockMvc.perform(get("/cart/pizza")
                .principal(principal))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.customer.customerId").value(1));
    }

    @Test
    void deletePizzafromCart_Success() throws Exception {
        mockMvc.perform(delete("/cart/deletePizza/1")
                .principal(principal))
                .andExpect(status().isOk());

        verify(cartService, times(1)).deletePizzafromCart(1);
    }



    @Test
    void getTotalOrderPrice_Success() throws Exception {
        when(customerRepository.findByUsername("testuser")).thenReturn(customer);
        when(cartService.getTotalOrderPrice(customer)).thenReturn(20.0);

        mockMvc.perform(get("/cart/orderprice")
                .principal(principal))
                .andExpect(status().isOk())
                .andExpect(content().string("20.0"));
    }

}
