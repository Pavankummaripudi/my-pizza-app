package com.cg.pizza.pizzaTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.pizza.entity.Orders;
import com.cg.pizza.service.OrdersService;

public class OrdersServiceTest {

    @Mock
    private OrdersService ordersService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testAddOrder() {
        int customerId = 1;
        Orders order = new Orders();
        when(ordersService.addOrder(customerId)).thenReturn(order);

        Orders result = ordersService.addOrder(customerId);

        assertNotNull(result);
        verify(ordersService, times(1)).addOrder(customerId);
    }

    @Test
    public void testCancelOrder() {
        int orderId = 1;
        Orders order = new Orders();
        when(ordersService.cancelOrder(orderId)).thenReturn(order);

        Orders result = ordersService.cancelOrder(orderId);

        assertNotNull(result);
        verify(ordersService, times(1)).cancelOrder(orderId);
    }

    @Test
    public void testFindAll() {
        List<Orders> ordersList = Arrays.asList(new Orders(), new Orders());
        when(ordersService.findAll()).thenReturn(ordersList);

        List<Orders> result = ordersService.findAll();

        assertNotNull(result);
        assertEquals(2, result.size());
        verify(ordersService, times(1)).findAll();
    }

    @Test
    public void testGetOrdersByCustomerId() {
        int customerId = 1;
        List<Orders> ordersList = Arrays.asList(new Orders(), new Orders());
        when(ordersService.getOrdersByCustomerId(customerId)).thenReturn(ordersList);

        List<Orders> result = ordersService.getOrdersByCustomerId(customerId);

        assertNotNull(result);
        assertEquals(2, result.size());
        verify(ordersService, times(1)).getOrdersByCustomerId(customerId);
    }

    @Test
    public void testUpdateOrderStatus() {
        int orderId = 1;
        Orders order = new Orders();
        when(ordersService.updateOrderStatus(orderId)).thenReturn(order);

        Orders result = ordersService.updateOrderStatus(orderId);

        assertNotNull(result);
        verify(ordersService, times(1)).updateOrderStatus(orderId);
    }
}
