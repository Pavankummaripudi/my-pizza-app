package com.cg.pizza.pizzaTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.pizza.dto.CartDTO;
import com.cg.pizza.dto.PizzaToppingsDTO;
import com.cg.pizza.entity.Cart;
import com.cg.pizza.entity.Customer;
import com.cg.pizza.entity.Pizza;
import com.cg.pizza.entity.PizzaToppings;
import com.cg.pizza.entity.Toppings;
import com.cg.pizza.exceptions.ApplicationException;
import com.cg.pizza.repository.CartRepository;
import com.cg.pizza.repository.CustomerRepo;
import com.cg.pizza.repository.PizzaRepository;
import com.cg.pizza.repository.PizzaToppingsRepository;
import com.cg.pizza.repository.ToppingsRepository;
import com.cg.pizza.serviceimpl.CartServiceImpl;

@ExtendWith(MockitoExtension.class)
public class CartServiceImplTest {

    @InjectMocks
    private CartServiceImpl cartServiceImpl;

    @Mock
    private PizzaRepository pizzaRepository;

    @Mock
    private CartRepository cartRepository;

    @Mock
    private CustomerRepo customerRepository;

    @Mock
    private ToppingsRepository toppingsRepository;

    @Mock
    private PizzaToppingsRepository ptRepo;

    private Customer customer;
    private Pizza pizza;
    private Toppings topping;
    private PizzaToppings pizzaToppings;
    private Cart cart;

    @BeforeEach
    void setUp() {
        customer = new Customer();
        customer.setCustomerId(1);
        pizza = new Pizza();
        pizza.setPizzaId(1);
        pizza.setPizzaPrice(10.0);
        topping = new Toppings();
        topping.setToppingId(1);
        topping.setToppingPrice(2.0);
        pizzaToppings = new PizzaToppings();
        pizzaToppings.setPtId(1);
        pizzaToppings.setPizza(pizza);
        pizzaToppings.setToppings(List.of(topping));
        pizzaToppings.setPizzaQuantity(1);
        cart = new Cart();
        cart.setCustomer(customer);
        cart.setPizzaToppings(List.of(pizzaToppings));
    }

    @Test
    void addPizzatoCart_CustomerNotFound() {
        CartDTO cartDTO = new CartDTO();
        cartDTO.setCustomerId(1);
        cartDTO.setPizzaToppingId(1);

        when(customerRepository.findById(1)).thenReturn(Optional.empty());

        assertThrows(ApplicationException.class, () -> cartServiceImpl.addPizzatoCart(cartDTO));
    }

    @Test
    void addPizzatoCart_PizzaToppingNotFound() {
        CartDTO cartDTO = new CartDTO();
        cartDTO.setCustomerId(1);
        cartDTO.setPizzaToppingId(1);

        when(customerRepository.findById(1)).thenReturn(Optional.of(customer));
        when(ptRepo.findById(1)).thenReturn(Optional.empty());

        assertThrows(ApplicationException.class, () -> cartServiceImpl.addPizzatoCart(cartDTO));
    }




    @Test
    void getCartItemsByCustomerId_CustomerNotFound() {
        when(customerRepository.findById(1)).thenReturn(Optional.empty());
        assertThrows(ApplicationException.class, () -> cartServiceImpl.getCartItemsByCustomerId(1));
    }

    @Test
    void getCartItemsByCustomerId_Success() {
        when(customerRepository.findById(1)).thenReturn(Optional.of(customer));
        when(cartRepository.findByCustomer(customer)).thenReturn(cart);

        Cart result = cartServiceImpl.getCartItemsByCustomerId(1);
        assertEquals(cart, result);
    }

    @Test
    void updatePizzaQuantity_Success() {
        when(ptRepo.findById(1)).thenReturn(Optional.of(pizzaToppings));
        when(ptRepo.save(pizzaToppings)).thenReturn(pizzaToppings);

        PizzaToppings result = cartServiceImpl.updatePizzaQuantity(pizzaToppings);
        assertEquals(pizzaToppings, result);
    }

    @Test
    void deleteCartItemsByCustomerId_CustomerNotFound() {
        when(customerRepository.findById(1)).thenReturn(Optional.empty());
        assertThrows(ApplicationException.class, () -> cartServiceImpl.deleteCartItemsByCustomerId(1));
    }

    @Test
    void deleteCartItemsByCustomerId_Success() {
        when(customerRepository.findById(1)).thenReturn(Optional.of(customer));
        when(cartRepository.findByCustomer(customer)).thenReturn(cart);

        cartServiceImpl.deleteCartItemsByCustomerId(1);
        verify(cartRepository, times(1)).delete(cart);
    }

    @Test
    void deletePizzafromCart_Success() {
        cartServiceImpl.deletePizzafromCart(1);
        verify(cartRepository, times(1)).deleteByPizzaToppingsId(1);
    }

    @Test
    void getTotalOrderPrice_Success() {
        when(cartRepository.findByCustomer(customer)).thenReturn(cart);

        double total = cartServiceImpl.getTotalOrderPrice(customer);
        assertEquals(12.0, total);
    }

    @Test
    void addPizzaToppings_Success() {
        PizzaToppingsDTO ptDTO = new PizzaToppingsDTO();
        ptDTO.setPizzaId(1);
        
        when(pizzaRepository.findByPizzaId(1)).thenReturn(pizza);
        when(toppingsRepository.findById(1)).thenReturn(Optional.of(topping));
        when(ptRepo.save(any(PizzaToppings.class))).thenReturn(pizzaToppings);

        PizzaToppings result = cartServiceImpl.addPizzaToppings(ptDTO, 1);
        assertEquals(pizzaToppings, result);
    }

    @Test
    void deletePizzaToppings_Success() {
        cartServiceImpl.deletePizzaToppings(1);
        verify(ptRepo, times(1)).deleteById(1);
    }

    @Test
    void getAllPizzaToppings_Success() {
        List<PizzaToppings> pizzaToppingsList = List.of(pizzaToppings);
        when(ptRepo.findAll()).thenReturn(pizzaToppingsList);

        List<PizzaToppings> result = cartServiceImpl.getAllPizzaToppings();
        assertEquals(pizzaToppingsList, result);
    }
}
